import qspyview as qpv
import socket
import Tkinter
import copy


class qaud_client(qpv.ThreadedClient):
    def __init__(self, root, sock, current_packet, var_config):
        qpv.ThreadedClient.__init__(self, root, sock, current_packet, var_config)
        
    def rec70(self, bdata):
        tstamp = ""
        #the following string 
        string = ""
        string = ("Quad Status " + str(bdata[7]) + " " + str(bdata[11]) + " " + str(bdata[13]) + " " 
                 + str(bdata[15]) + " " + str(bdata[17]) + " " + str(bdata[19]) + " " 
                 + str(bdata[21]) + " "+ str(bdata[23]) + " " + str(bdata[25]))
        # to process more data, keep appending string with " " data, then deal with the now extended array in processIncoming data

        
        string += "\n"
        self.current_packet[1] = string
        self.current_packet[0] = 1
        self.queue.put(copy.copy(self.current_packet))
        
        
sock = socket.socket(socket.AF_INET, # Internet
                         socket.SOCK_DGRAM) # UDP
sock.settimeout(10)
root = Tkinter.Tk()
var_config = []
for i in range(0, 124):
    var_config.append(Tkinter.IntVar())
    if i >= 70:
        var_config[i].set(True)
    else:
        var_config[i].set(False)
            
var_config[64].set(True)
current_packet = [0, "None", 0, 0, 0, 0, 0, 1, 1] # command num, printstr, tx, rx_from_qspy, err_from_qspy, rx_from_qp, err_from_qp, rx_check_num, tx_check_num
client = qaud_client(root, sock, current_packet, var_config)
root.mainloop()