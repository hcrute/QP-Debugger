import Tkinter
import time
import threading
import random
import Queue
import socket
import sys
import binascii
import tkMessageBox
import copy

    
'''
def pause(sock):
    print "Here"
    value = []
    value.append(1)
    value.append(16)
    value.append(6)
    value.append(6)
    value.append(1)
    #value.append(0)
    MESSAGE = bytearray(value)
    MESSAGE.append(0)
    print MESSAGE
    print sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
    #pause sent
    current_packet[8] += 1
'''    
class GuiPart:
    def __init__(self, master, queue, endCommand, sock, client, var_config):
        self.queue = queue
        self.master = master
        self.sock = sock
        self.end = endCommand
        self.client = client
        self.log_setting = Tkinter.IntVar()
        self.log_setting.set(True)
        self.log_location = "QSpyLog.txt"
        self.file = open(self.log_location, "w+")
        self.var_config = var_config
        # Set up the GUI
        master.title("QSpy Viewer")
        root.protocol('WM_DELETE_WINDOW', lambda:self.exit_function())
        
        menubar = Tkinter.Menu(master)
        master.config(menu=menubar)
        filemenu = Tkinter.Menu(menubar, tearoff=0)
        filemenu.add_command(label="Store Dictionaries", command=lambda:self.send_data_on_click(self,  0))
        filemenu.add_command(label="Screen Output", command=lambda:self.send_data_on_click(self, 1))
        filemenu.add_command(label="Save QS Binary", command=lambda:self.send_data_on_click(self,  2))
        filemenu.add_command(label="Matlab Output", command=lambda:self.send_data_on_click(self,  3))
        filemenu.add_command(label="MscGen Output", command=lambda:self.send_data_on_click(self,  4))
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=endCommand)
        menubar.add_cascade(label="File", menu=filemenu)
        ''' SEE QSPY GUI
        viewmenu = Tkinter.Menu(menubar, tearoff=0)
        viewmenu.add_command(label="Text", command=self.donothing)
        viewmenu.add_command(label="Canvas", command=self.donothing)
        menubar.add_cascade(label="View", menu=viewmenu)
        '''
        filtermenu = Tkinter.Menu(menubar, tearoff=0)
        filtermenu.add_command(label="Global Filters...", command=lambda:self.onClick(4))
        filtermenu.add_command(label="Local Filters...", command=lambda:self.onClick(5))
        filtermenu.add_command(label="AO Filter...", command=lambda:self.onClick(6))
        menubar.add_cascade(label="Filters", menu=filtermenu)

        cmdmenu = Tkinter.Menu(menubar, tearoff=0)
        cmdmenu.add_command(label="Reset Target", command=self.send_reset)
        cmdmenu.add_command(label="Query Target Info", command=self.send_query_info)
        cmdmenu.add_command(label="Tick[0]", command=lambda:self.send_tick(0))
        cmdmenu.add_command(label="Tick[1]", command=lambda:self.send_tick(1))
        cmdmenu.add_command(label="User Command...", command=lambda:self.onClick(0))
        cmdmenu.add_command(label="Peek Address...", command=lambda:self.onClick(1))
        cmdmenu.add_command(label="Poke Address...", command=lambda:self.onClick(2))
        cmdmenu.add_separator()
        menubar.add_cascade(label="Commands", menu=cmdmenu)

        eventmenu = Tkinter.Menu(menubar, tearoff=0)
        eventmenu.add_command(label="Generate Event...", command=lambda:self.onClick(3))
        menubar.add_cascade(label="Events", menu=eventmenu)
        
        eventmenu = Tkinter.Menu(menubar, tearoff=0)
        eventmenu.add_command(label="Log Settings", command=lambda:self.onClick(7))
        menubar.add_cascade(label="Log", menu=eventmenu)
        ''' UNCERTAIN OF FUNCTION
        custommenu = Tkinter.Menu(menubar, tearoff=0)
        custommenu.add_command(label="MyCommand", command=self.donothing)
        menubar.add_cascade(label="Custom", menu=custommenu)
        
        helpmenu = Tkinter.Menu(menubar, tearoff=0)
        helpmenu.add_command(label="Online Help", command=self.donothing)
        helpmenu.add_separator()
        helpmenu.add_command(label="About...", command=self.donothing)
        menubar.add_cascade(label="Help", menu=helpmenu)
        '''
        
        master.display_frame = Tkinter.Frame(master, width =640, height = 270 )
        master.display_frame.pack(fill = "both", expand = True)
        master.display_frame.grid_propagate(False)
        master.display_frame.grid_rowconfigure(0, weight = 1)
        master.display_frame.grid_columnconfigure(0, weight = 1)
        
        
        master.scrollbary = Tkinter.Scrollbar(master.display_frame)
        master.scrollbary.grid(row=0, column=1, sticky="nsew")

        master.scrollbarx = Tkinter.Scrollbar(master.display_frame,orient=Tkinter.HORIZONTAL)
        master.scrollbarx.grid(row=1, column=0, sticky="nsew")
        
        master.text = Tkinter.Text(master.display_frame, width=65, height=12, relief="sunken", wrap=Tkinter.NONE)
        master.text.config(state=Tkinter.NORMAL, yscrollcommand = master.scrollbary.set, xscrollcommand = master.scrollbarx.set, font = "ariel 8")
        master.text.grid(row=0, column=0, sticky='nsew')
        master.scrollbary.config(command = master.text.yview)
        master.scrollbarx.config(command = master.text.xview)
        
        master.target_label = Tkinter.Label(master, text="Target : UNKNOWN")
        master.target_label.pack(side=Tkinter.LEFT)
        master.tx_label = Tkinter.Label(master, text = "   Viewer: TX")
        master.tx_label.pack(side=Tkinter.LEFT)
        master.tx_display = Tkinter.Label(master, text="0", relief="sunken", width = 4, anchor=Tkinter.W)
        master.tx_display.pack(side=Tkinter.LEFT)
        master.rx1_label = Tkinter.Label(master, text = "RX")
        master.rx1_label.pack(side=Tkinter.LEFT)
        master.rx1_display = Tkinter.Label(master, text="0", relief="sunken", width = 4, anchor=Tkinter.W)
        master.rx1_display.pack(side=Tkinter.LEFT)
        master.err1_label = Tkinter.Label(master, text = "Err")
        master.err1_label.pack(side=Tkinter.LEFT)
        master.err1_display = Tkinter.Label(master, text="0", relief="sunken", width = 4, anchor=Tkinter.W)
        master.err1_display.pack(side=Tkinter.LEFT)
        master.rx2_label = Tkinter.Label(master, text = "   Backend: RX")
        master.rx2_label.pack(side=Tkinter.LEFT)
        master.rx2_display = Tkinter.Label(master, text="0", relief="sunken", width = 4, anchor=Tkinter.W)
        master.rx2_display.pack(side=Tkinter.LEFT)
        master.err2_label = Tkinter.Label(master, text = "Err")
        master.err2_label.pack(side=Tkinter.LEFT)
        master.err2_display = Tkinter.Label(master, text="0", relief="sunken", width = 4, anchor=Tkinter.W)
        master.err2_display.pack(side=Tkinter.LEFT)
        #master.button = Tkinter.Button(master, text="Pause", command=lambda:pause(self.sock))
        #master.button.pack()
        
        # Add more GUI stuff here depending on your specific needs
    def exit_function(self):
        
        values = []
        self.client.running = 0
        values.append(self.client.current_packet[8])
        values.append(129)
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        #put values into a bytearray, then buffer to be able to send
        MESSAGE = bytearray(values) 
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        self.sock.close()
        self.master.destroy()
        
    def check_retry(self):
        return tkMessageBox.askretrycancel("QSpy Viewer", "QSpy Connection Failed")
    
    def donothing(self):
        tkMessageBox.showinfo("a box", "Hello!")
        
    def send_data_on_click(self, cmd):
        
        self.client.current_packet[0] = 1
        printstr = ""
        if cmd == 0:
            self.save_dict(sock)
            printstr = "Dict Saved"
        elif cmd == 1:
            self.save_screen(sock)
            printstr = "Text Saved"
        elif cmd == 2:
            self.save_bin(sock)
            printstr = "Binary Saved"
        elif cmd == 3:
            self.save_matlab(sock)
            printstr = "Matlab Saved"
        elif cmd == 4:
            self.save_mscgen(sock)
            printstr = "MSCGEN Saved"
        else:
            printstr = "Nothing Done"
        self.queue.put(copy.copy(self.client.current_packet))
    

    class MyDialog:
        def __init__(self, gui, root, num):
            self.gui= gui
            codes = [ "QS_QEP_STATE_ENTRY", "QS_QEP_STATE_EXIT", "QS_QEP_STATE_INIT", "QS_QEP_INIT_TRAN", "QS_QEP_INTERN_TRAN", "QS_QEP_TRAN",
                       "QS_QEP_IGNORED", "QS_QEP_DISPATCH", "QS_QEP_UNHANDLED", "QS_QEP_TRAN_HIST", "QS_QEP_TRAN_EP", "QS_QEP_TRAN_XP", "QS_QEP_RESERVED1",
                       "QS_QEP_RESERVED0", "QS_QF_ACTIVE_ADD", "QS_QF_ACTIVE_REMOVE", "QS_QF_ACTIVE_SUBSCRIBE", "QS_QF_ACTIVE_UNSUBSCRIBE", 
                       "QS_QF_ACTIVE_POST_FIFO", "QS_QF_ACTIVE_POST_LIFO", "QS_QF_ACTIVE_GET", "QS_QF_ACTIVE_GET_LAST", "QS_QF_EQUEUE_INIT", 
                       "QS_QF_EQUEUE_POST_FIFO", "QS_QF_EQUEUE_POST_LIFO", "QS_QF_EQUEUE_GET", "QS_QF_EQUEUE_GET_LAST", "QS_QF_MPOOL_INIT", 
                       "QS_QF_MPOOL_GET", "QS_QF_MPOOL_PUT", "QS_QF_PUBLISH", "QS_QF_RESERVED", "QS_QF_NEW", "QS_QF_GC_ATTEMPT", "QS_QF_GC",
                       "QS_QF_TICK", "QS_QF_TIMEEVT_ARM", "QS_QF_TIMEEVT_AUTO_DISARM", "QS_QF_TIMEEVT_DISARM_ATTEMPT", "QS_QF_TIMEEVT_DISARM", 
                       "QS_QF_TIMEEVT_REARM", "QS_QF_TIMEEVT_POST", "QS_QF_TIMEEVT_CTR", "QS_QF_CRIT_ENTRY",  "QS_QF_ISR_ENTRY",
                       "QS_QF_ISR_EXIT", "QS_QF_INT_DISABLE", "QS_QF_INT_ENABLE", "QS_QF_ACTIVE_POST_ATTEMPT", "QS_QF_EQUEUE_POST_ATTEMPT", 
                       "QS_QF_MPOOL_GET_ATTEMPT", "QS_QF_RESERVED1", "QS_QF_RESERVED0", "QS_SCHED_LOCK", "QS_SCHED_UNLOCK", "QS_SCHED_NEXT", 
                       "QS_SHEC_IDLE", "QS_SCHED_RESUME"]
            if num == 0:
                top = self.top = Tkinter.Toplevel(root)
                self.myLabel = Tkinter.Label(top, text='cmdId:')
                self.myLabel.grid(row=0)

                self.myEntryBox1 = Tkinter.Entry(top, width=4)
                self.myEntryBox1.grid(row=0, column=1, sticky="W")
                
                self.myLabel = Tkinter.Label(top, text='param:')
                self.myLabel.grid(row=1)

                self.myEntryBox2 = Tkinter.Entry(top, width=10)
                self.myEntryBox2.grid(row=1, column=1, sticky="W")
                
                self.mySubmitButton = Tkinter.Button(top, text='OK', command=lambda:self.send(num))
                self.mySubmitButton.grid(row=2, sticky="E")
                self.myCancelButton = Tkinter.Button(top, text='Cancel', command=lambda:self.cancel())
                self.myCancelButton.grid(row=2, column=1, sticky="W")
            elif num == 1:
                top = self.top = Tkinter.Toplevel(root)
                self.myLabel = Tkinter.Label(top, text='adress:')
                self.myLabel.grid(row=0)

                self.myEntryBox1 = Tkinter.Entry(top, width=12)
                self.myEntryBox1.grid(row=0, column=1, sticky="W")
                
                self.myLabel = Tkinter.Label(top, text='bytes:')
                self.myLabel.grid(row=1)

                self.myEntryBox2 = Tkinter.Entry(top, width=8)
                self.myEntryBox2.grid(row=1, column=1, sticky="W")
                
                self.mySubmitButton = Tkinter.Button(top, text='OK', command=lambda:self.send(num))
                self.mySubmitButton.grid(row=2, sticky="E")
                self.myCancelButton = Tkinter.Button(top, text='Cancel', command=lambda:self.cancel())
                self.myCancelButton.grid(row=2, column=1, sticky="W")
            elif num == 2:
                top = self.top = Tkinter.Toplevel(root)
                self.myLabel = Tkinter.Label(top, text='adress:')
                self.myLabel.grid(row=0)

                self.myEntryBox1 = Tkinter.Entry(top, width=12)
                self.myEntryBox1.grid(row=0, column=1, sticky="W")
                
                self.myLabel = Tkinter.Label(top, text='format:')
                self.myLabel.grid(row=1)

                self.myEntryBox2 = Tkinter.Entry(top, width=4)
                self.myEntryBox2.grid(row=1, column=1, sticky="W")
                
                self.myEntryBox3 = Tkinter.Entry(top, width=12)
                self.myEntryBox3.grid(row=2, column=1, sticky="W")
                
                self.myLabel = Tkinter.Label(top, text='data:')
                self.myLabel.grid(row=2)
                
                self.mySubmitButton = Tkinter.Button(top, text='OK', command=lambda:self.send(num))
                self.mySubmitButton.grid(row=3, sticky="E")
                self.myCancelButton = Tkinter.Button(top, text='Cancel', command=lambda:self.cancel())
                self.myCancelButton.grid(row=3, column=1, sticky="W")
            elif num == 3:
                top = self.top = Tkinter.Toplevel(root)
                self.myLabel = Tkinter.Label(top, text='prio:')
                self.myLabel.grid(row=0)

                self.myEntryBox1 = Tkinter.Entry(top, width=3)
                self.myEntryBox1.grid(row=0, column=1, sticky="W")
                
                self.myLabel = Tkinter.Label(top, text='sig:')
                self.myLabel.grid(row=1)
                
                self.myEntryBox2 = Tkinter.Entry(top, width=3)
                self.myEntryBox2.grid(row=1, column=1, sticky="W")
                
                self.myLabel = Tkinter.Label(top, text="==EVENT PARAMETERS==")
                self.myLabel.grid(row=2,  sticky="EW", columnspan=3)
                
                self.myLabel = Tkinter.Label(top, text='par1:')
                self.myLabel.grid(row=3)
                
                self.myEntryBox3 = Tkinter.Entry(top, width=3)
                self.myEntryBox3.grid(row=3, column=1, sticky="W")
                self.myEntryBox4 = Tkinter.Entry(top, width=12)
                self.myEntryBox4.grid(row=3, column=2, sticky="EW")
                
                self.myLabel = Tkinter.Label(top, text='par2:')
                self.myLabel.grid(row=4)
                
                self.myEntryBox5 = Tkinter.Entry(top, width=3)
                self.myEntryBox5.grid(row=4, column=1, sticky="W")
                self.myEntryBox6 = Tkinter.Entry(top, width=12)
                self.myEntryBox6.grid(row=4, column=2, sticky="EW")
                
                
                self.mySubmitButton = Tkinter.Button(top, text='OK', command=lambda:self.send(num))
                self.mySubmitButton.grid(row=5, sticky="E")
                self.myCancelButton = Tkinter.Button(top, text='Cancel', command=lambda:self.cancel())
                self.myCancelButton.grid(row=5, column=1, sticky="W")
            elif num == 4:
                top = self.top = Tkinter.Toplevel(root)
                self.myLabel = Tkinter.Label(top, text="==EVENT PARAMETERS==")
                self.myLabel.grid(row=0,  sticky="EW", columnspan=4)
                self.myLabel = Tkinter.Label(top, text='QEP records:')
                self.myLabel.grid(row=1, column=0)
                self.myLabel = Tkinter.Label(top, text='QF records:')
                self.myLabel.grid(row=1, column=1)
                i = 0
                row = 0
                column = 0
                for c in codes:
                    row = i + 2
                    if row > 45:
                        row -=44
                        column = 3
                    elif row > 30:
                        row -= 29
                        column = 2
                    elif row > 15:
                        row -=14
                        column = 1
                    
                  
                    c = Tkinter.Checkbutton(top, text=c, variable=self.var_config[i])
                    c.grid(row=row, column=column, sticky="W")
                    i += 1
                row = 1
                column = 0
                self.myLabel = Tkinter.Label(top, text="==USER PARAMETERS==")
                self.myLabel.grid(row=17,  sticky="EW", columnspan=4)
                i+=1
                for i in range(i, i+52):
                    if row > 33:
                        row = 1
                        column += 1
                    elif row > 22:
                        row = 1
                        column += 1
                    elif row > 11:
                        row = 1
                        column += 1
                    title = "QS_USER("+str(i+11)+")"
                    c = Tkinter.Checkbutton(top, text=title, variable=self.var_config[i+11])
                    c.grid(row=row + 17 , column=column, sticky="W")
                    row += 1
                self.mySubmitButton = Tkinter.Button(top, text='OK', command=lambda:self.send(num))
                self.mySubmitButton.grid(row=i+2, sticky="EW", columnspan=5)
            elif num == 5:
                top = self.top = Tkinter.Toplevel(root)
                self.myLabel = Tkinter.Label(top, text="QS_FILTER_SM_OBJ:")
                self.myLabel.grid(row = 0)
                self.myEntryBox1 = Tkinter.Entry(top, width=12)
                self.myEntryBox1.grid(row=0, column=1, sticky="W")
                self.myLabel = Tkinter.Label(top, text="QS_FILTER_AO_OBJ:")
                self.myLabel.grid(row = 1)
                self.myEntryBox2 = Tkinter.Entry(top, width=12)
                self.myEntryBox2.grid(row=1, column=1, sticky="W")
                self.myLabel = Tkinter.Label(top, text="QS_FILTER_MP_OBJ:")
                self.myLabel.grid(row = 2)
                self.myEntryBox3 = Tkinter.Entry(top, width=12)
                self.myEntryBox3.grid(row=2, column=1, sticky="W")
                self.myLabel = Tkinter.Label(top, text="QS_FILTER_EQ_OBJ:")
                self.myLabel.grid(row = 3)
                self.myEntryBox4 = Tkinter.Entry(top, width=12)
                self.myEntryBox4.grid(row=3, column=1, sticky="W")
                self.myLabel = Tkinter.Label(top, text="QS_FILTER_TE_OBJ:")
                self.myLabel.grid(row = 4)
                self.myEntryBox5 = Tkinter.Entry(top, width=12)
                self.myEntryBox5.grid(row=4, column=1, sticky="W")
                self.myLabel = Tkinter.Label(top, text="QS_FILTER_AP_OBJ:")
                self.myLabel.grid(row = 5)
                self.myEntryBox6 = Tkinter.Entry(top, width=12)
                self.myEntryBox6.grid(row=5, column=1, sticky="W")
                self.mySubmitButton = Tkinter.Button(top, text='OK', command=lambda:self.send(num))
                self.mySubmitButton.grid(row=6, sticky="E")
                self.myCancelButton = Tkinter.Button(top, text='Cancel', command=lambda:self.cancel())
                self.myCancelButton.grid(row=6, column=1, sticky="W")
            elif num == 6:
                top = self.top = Tkinter.Toplevel(root)
                self.myLabel = Tkinter.Label(top, text="prio:")
                self.myLabel.grid(row = 0)
                self.myEntryBox1 = Tkinter.Entry(top, width=12)
                self.myEntryBox1.grid(row=0, column=1, sticky="W")
                self.mySubmitButton = Tkinter.Button(top, text='OK', command=lambda:self.send(num))
                self.mySubmitButton.grid(row=1, sticky="E")
                self.myCancelButton = Tkinter.Button(top, text='Cancel', command=lambda:self.cancel())
                self.myCancelButton.grid(row=1, column=1, sticky="W")
            elif num == 7:
                top = self.top = Tkinter.Toplevel(root)
                
                c = Tkinter.Checkbutton(top, text="Log Data ", variable=self.gui.log_setting)
                c.grid(row=0, column=0, sticky="W")
                self.myLabel = Tkinter.Label(top, text='Log Name:')
                self.myLabel.grid(row=1)
                self.myEntryBox1 = Tkinter.Entry(top, width=12)
                self.myEntryBox1.insert(Tkinter.END, self.gui.log_location)
                self.myEntryBox1.grid(row=1, column=1, sticky="W")
                self.mySubmitButton = Tkinter.Button(top, text='OK', command=lambda:self.send(num))
                self.mySubmitButton.grid(row=2, sticky="E")

        def cancel(self):
            self.top.destroy()
            
        def send(self, num):
            global address
            global bytes
            global cmd_id
            global params
            global format
            global data
            global prio
            global sig
            global par1_fmt
            global par1_value
            global par2_fmt
            global par2_value
            global sm
            global ao
            global mp
            global eo
            global te
            global ap
            par1_fmt = ""
            par2_fmt = ""
            par1_value = ""
            par2_value = ""
            if num == 0:
                cmd_id = self.myEntryBox1.get()
                params = self.myEntryBox2.get()
            elif num == 1:
               address = self.myEntryBox1.get()
               bytes = self.myEntryBox2.get()
            elif num == 2:
               address = self.myEntryBox1.get()
               format = self.myEntryBox2.get()
               data = self.myEntryBox3.get()
            elif num == 3:
                prio = self.myEntryBox1.get()
                sig = self.myEntryBox2.get()
                par1_fmt = self.myEntryBox3.get()
                par2_fmt = self.myEntryBox5.get()
                par1_value = self.myEntryBox4.get()
                par2_value = self.myEntryBox6.get()
            elif num == 5:
                sm = self.myEntryBox1.get()
                ao = self.myEntryBox2.get()
                mp = self.myEntryBox3.get()
                eq = self.myEntryBox4.get()
                te = self.myEntryBox5.get()
                ap = self.myEntryBox6.get()
            elif num == 6:
                ao = self.myEntryBox1.get()
            elif num == 7:
                if self.gui.log_location != self.myEntryBox1.get():
                    self.gui.log_location = self.myEntryBox1.get()
                    self.gui.file.close()
                    self.gui.file = open(self.gui.log_location, "w+")
            self.top.destroy()
                    
    def onClick(self, num):
        inputDialog = self.MyDialog(self, self.master, num)
        self.master.wait_window(inputDialog.top)
        try:
            if num == 0:
                self.send_command(cmd_id, params)        
            elif num == 1:
                self.send_peek(address, bytes)
            elif num == 2:
                self.send_poke(address, format, data)    
            elif num == 3:
                self.send_event(prio, sig, par1_fmt, par1_value, par2_fmt, par2_value)
            elif num == 5:
                self.send_local_filter(sm, ao, mp, eq, te, ap)
            elif num == 6:
                self.send_ao_filter(ao)
                
        except:
            print "Undefined variables"
        
    def processIncoming(self):
        """Handle all messages currently in the queue, if any."""
        #if self.queue.qsize():
           # print "Unloading Queue"
        while self.queue.qsize(  ):
            try:
                msg = self.queue.get(0)
                #print msg
                # Check contents of message and do whatever is needed. As a
                # simple test, print it (in real life, you would
                # suitably update the GUI's display in a richer fashion).
               
                if msg[0] == 1:
                    self.master.text.config(state=Tkinter.NORMAL)
                    self.master.text.insert(Tkinter.END, str(msg[1]))
                    self.master.text.config(state=Tkinter.DISABLED)
                    self.master.text.see(Tkinter.END)
                    if self.log_setting.get():
                        self.file.write(str(msg[1]))
                elif msg[0] == 2:
                    self.master.text.config(state=Tkinter.NORMAL)
                    self.master.text.insert(Tkinter.END, "\nTarget Connected\n")
                    self.master.text.config(state=Tkinter.DISABLED)
                    self.master.text.see(Tkinter.END)
                    if self.log_setting.get():
                        self.file.write("\nTarget Connected\n"+str(msg[1])+"\n")
                    self.master.target_label.config(text=str(msg[1]))
                elif msg[0] == -1:
                    self.master.text.config(state=Tkinter.NORMAL)
                    self.master.text.insert(Tkinter.END, str(msg[1]))
                    self.master.text.config(state=Tkinter.DISABLED)
                    self.master.text.see(Tkinter.END)
                    if self.log_setting.get():
                        self.file.write(str(msg[1]))
                elif msg[0] == -2:
                    self.master.text.config(state=Tkinter.NORMAL)
                    self.master.text.insert(Tkinter.END, str(msg[1]))
                    self.master.text.config(state=Tkinter.DISABLED)
                    self.master.text.see(Tkinter.END)
                    if self.log_setting.get():
                        self.file.write(str(msg[1]))
                    if self.check_retry():
                        self.client.start_connection(self.sock, self.queue)
                    else:
                        sys.exit(1)
                    
                    
                self.master.tx_display.config(text=(str(msg[2])))
                self.master.rx1_display.config(text=(str(msg[3])))
                self.master.err1_display.config(text=(str(msg[4])))
                self.master.rx2_display.config(text=(str(msg[5])))
                self.master.err2_display.config(text=(str(msg[6])))
                
            except Queue.Empty:
                # just on general principles, although we don't
                # expect this branch to be taken in this case
                pass
    def save_screen(self):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []
        values.append(self.client.current_packet[8])
        values.append(131) # send a packet with the rec id 131 to tell QSpy to save the output to the screen as a text file
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        #print "\nScreen Saved"
        self.client.current_packet[8] += 1
    
    def save_matlab(self):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []
        values.append(self.client.current_packet[8])
        values.append(133) # send a packet with the rec id 133 to tell QSpy to save the output to the screen as a matlab file
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        #print "\nMatlab Saved"
        self.client.current_packet[8] += 1
        
    def save_mscgen(self):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []
        values.append(self.client.current_packet[8])
        values.append(134) # send a packet with the rec id 134 to tell QSpy to save the output to the screen as a mscgen file
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        #print "\nMSCGEN Saved"
        self.client.current_packet[8] += 1
        
    def save_bin(self):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []
        values.append(self.client.current_packet[8])
        values.append(132) # send a packet with the rec id 132 to tell QSpy to save the output to the screen as a binary file
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        #print "\nBinary Saved"
        self.client.current_packet[8] += 1
        
        
    def save_dict(self):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []
        values.append(self.client.current_packet[8])
        values.append(130)# send a packet with the rec id 130 to tell QSpy to save the output to the screen as a dictionary file
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        #print "\nDict Saved"
        self.client.current_packet[8] += 1
        
        
        
    def send_reset(self):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []
        values.append(self.client.current_packet[8])
        values.append(2) # send a packet with the rec id 2 to tell QSpy to reset target
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        #print "\nMSCGEN Saved"
        self.client.current_packet[8] += 1
        self.client.current_packet[2] += 1
        
    def send_query_info(self):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []
        values.append(self.client.current_packet[8])
        values.append(0) # send a packet with the rec id 0 to tell QSpy to query target info
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        #print "\nMSCGEN Saved"
        self.client.current_packet[8] += 1
        self.client.current_packet[2] += 1
        
    def send_tick(self, rate):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []
        values.append(self.client.current_packet[8])
        values.append(3) # send a packet with the rec id 2 to tell QSpy to reset target
        values.append(rate)
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        #print "\nMSCGEN Saved"
        self.client.current_packet[8] += 1
        self.client.current_packet[2] += 1
        
    def send_command(self, id, params):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []

        values.append(self.client.current_packet[8])
        values.append(int(id)) # send a packet with the rec id 2 to tell QSpy to reset target
        for p in params:
            values.append(int(p))
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        #print "\nMSCGEN Saved"
        self.client.current_packet[8] += 1
        self.client.current_packet[2] += 1
        
    def send_peek(self, address, bytes):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []

        values.append(self.client.current_packet[8])
        values.append(int(4)) # send a packet with the rec id 2 to tell QSpy to reset target
        for a in address:
            values.append(int(a))
        values.append(int(bytes))
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        #print "\nMSCGEN Saved"
        self.client.current_packet[8] += 1
        self.client.current_packet[2] += 1
        
    def send_poke(self, address, format, data):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []
        values.append(self.client.current_packet[8])
        values.append(int(5)) # send a packet with the rec id 2 to tell QSpy to reset target
        values.append(int(address))
        values.append((format))
        for d in data:
            values.append(int(d))
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        #print "\nMSCGEN Saved"
        self.client.current_packet[8] += 1
        self.client.current_packet[2] += 1
        
    def send_local_filter(self, sm, ao, mp, eq, te, qp):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []
        values.append(self.client.current_packet[8])
        values.append(int(11))
        
        #send the SM
        values.append(int(0))
        values.append(sm)
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        self.client.current_packet[8] += 1
        self.client.current_packet[2] += 1
        values =[]
        values.append(self.client.current_packet[8])
        values.append(int(11))
        
        #send the AO
        values.append(int(1))
        values.append(ao)
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        self.client.current_packet[8] += 1
        self.client.current_packet[2] += 1
        values =[]
        values.append(self.client.current_packet[8])
        values.append(int(11))
        
        #send the MP
        values.append(int(2))
        values.append(mp)
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        self.client.current_packet[8] += 1
        self.client.current_packet[2] += 1
        values =[]
        values.append(self.client.current_packet[8])
        values.append(int(11))
        
        #send the EQ
        values.append(int(3))
        values.append(eq)
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        self.client.current_packet[8] += 1
        self.client.current_packet[2] += 1
        values =[]
        values.append(self.client.current_packet[8])
        values.append(int(11))
        
        #send the TE
        values.append(int(4))
        values.append(te)
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        self.client.current_packet[8] += 1
        self.client.current_packet[2] += 1
        values =[]
        values.append(self.client.current_packet[8])
        values.append(int(11))
        
        #send the AP
        values.append(int(5))
        values.append(eq)
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        self.client.current_packet[8] += 1
        self.client.current_packet[2] += 1
    def send_event(self, prio, sig, fmt1, var1, fmt2, var2):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []
        values.append(self.client.current_packet[8])
        values.append(16)
        values.append(prio)
        values.append(sig)
        
        if fmt1 != "":
            values.append(fmt1)
            values.append(var1)
        if fmt2 != "":
            values.append(fmt2)
            values.append(var2)
        
        if len(values) > 2:
            MESSAGE = bytearray(values)
            self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
            self.client.current_packet[8] += 1
            self.client.current_packet[2] += 1
        
    def send_ao_filter(self, ao):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        values = []
        values.append(self.client.current_packet[8])
        values.append(int(12))
        values.append(ao)
        MESSAGE = bytearray(values)
        self.sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        self.client.current_packet[8] += 1
        self.client.current_packet[2] += 1
        
        
class ThreadedClient:
    """
    Launch the main part of the GUI and the worker thread. periodicCall and
    endApplication could reside in the GUI part, but putting them here
    means that you have all the thread controls in a single place.
    """
    def __init__(self, master, sock, current_packet, var_config):
        """
        Start the GUI and the asynchronous threads. We are in the main
        (original) thread of the application, which will later be used by
        the GUI as well. We spawn a new thread for the worker (I/O).
        """
        self.var_config = var_config
        self.functions = [self.rec0, self.rec1, self.rec2, self.rec3, self.rec4, self.rec5, self.rec6, self.rec7, self.rec8,
                          self.rec9, self.rec10, self.rec11, self.rec12, self.rec13, self.rec14, self.rec15, self.rec16, self.rec17,
                          self.rec18, self.rec19, self.rec20, self.rec21, self.rec22, self.rec23, self.rec24, self.rec25, self.rec26,
                          self.rec27, self.rec28, self.rec29, self.rec30, self.rec31, self.rec32, self.rec33, self.rec34, self.rec35,
                          self.rec36, self.rec37, self.rec38, self.rec39, self.rec40, self.rec41, self.rec42, self.rec43, self.rec44,
                          self.rec45, self.rec46, self.rec47, self.rec48, self.rec49, self.rec50, self.rec51, self.rec52, self.rec53,
                          self.rec54, self.rec55, self.rec56, self.rec57, self.rec58, self.rec59, self.rec60, self.rec61, self.rec62,
                          self.rec63, self.rec64, self.rec65, self.rec66, self.rec67, self.rec68, self.rec69, self.rec70, self.rec71,
                          self.rec72, self.rec73, self.rec74, self.rec75, self.rec76, self.rec77, self.rec78, self.rec79, self.rec80,
                          self.rec81, self.rec82, self.rec83, self.rec84, self.rec85, self.rec86, self.rec87, self.rec88, self.rec89,
                          self.rec90, self.rec91, self.rec92, self.rec93, self.rec94, self.rec95, self.rec96, self.rec97, self.rec98,
                          self.rec99, self.rec100, self.rec101, self.rec102, self.rec103, self.rec104, self.rec105, self.rec106, self.rec107,
                          self.rec108, self.rec109, self.rec110, self.rec111, self.rec112, self.rec113, self.rec114, self.rec115, self.rec116,
                          self.rec117, self.rec118, self.rec119, self.rec120, self.rec121, self.rec122, self.rec123, self.rec124
                         ]
        
        self.master = master
        self.sock = sock
        self.current_packet = current_packet
        # Create the queue
        self.queue = Queue.Queue(  )
        # Set up the GUI part
        self.gui = GuiPart(master, self.queue, self.endApplication, sock, self, self.var_config)

        # Set up the thread to do asynchronous I/O
        # More threads can also be created and used, if necessary
        self.running = 1
        self.thread1 = threading.Thread(target=self.workerThread1,args=(self.sock, self.queue,))
        self.thread1.start()

        # Start the periodic call in the GUI to check if the queue contains
        # anything
        self.periodicCall(  )

    def periodicCall(self):
        """
        Check every 200 ms if there is something new in the queue.
        """
        self.gui.processIncoming(  )
        if not self.running:
            # This is the brutal stop of the system. You may want to do
            # some cleanup before actually shutting it down.
            import sys
            sys.exit(1)
        self.master.after(10, self.periodicCall)
        
    def start_connection(self, sock, queue):
        self.thread1 = threading.Thread(target=self.workerThread1, args=(sock, queue,))
        self.thread1.start()

    def workerThread1(self, sock, queue):
        """
        This is where we handle the asynchronous I/O. For example, it may be
        a 'select(  )'. One important thing to remember is that the thread has
        to yield control pretty regularly, by select or otherwise.
        """
        
        self.connect_to_qspy(sock, queue)
        
        # To simulate asynchronous I/O, we create a random number at
        # random intervals. Replace the following two lines with the real
        # thing.  TEMPLATE
        #time.sleep(rand.random(  ) * 1.5)
        #msg = rand.random(  )
        #self.queue.put(msg)
        
                
    def connect_to_qspy(self, sock, queue):
        MSG = []
        self.current_packet[0] = 0
        data = 0
        #connection info
        values = [1, 128]
        UDP_IP = "127.0.0.1"
        UDP_PORT = 7701
        #put values into a bytearray, then buffer to be able to send
        MESSAGE = bytearray(values) 
                
        try: 
            sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))# send message number one, rx id 128 to attach to qspy
            self.current_packet[8] += 1 #increment expected tx
            self.current_packet[2] += 1 #increment tx counter
            data, addr = sock.recvfrom(4096) # buffer size is 4096 bytes
            self.current_packet[3] += 1 #increment rx counter
            self.current_packet[7] += 1 #increment expected rx
           
            queue.put(copy.copy(self.current_packet))
            MESSAGE[1] = 0
            MESSAGE[0] = self.current_packet[7] # send message number two, rx id 0 to get the target ID
            print self.running
            sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
            self.current_packet[8] += 1 #increment expected tx
            self.current_packet[2] += 1 #increment tx counter
            
            self.current_packet[7] -= 1
            
            while 1:                
                data, addr = sock.recvfrom(4096) # receive data
                self.current_packet[3] += 1 #increment rx counter
                self.current_packet[7] += 1 #increment expected rx
                bdata = bytearray(data)     #place received data in a byte array for easy manipulation
                self.handle_message(bdata)
                
                            
        except socket.timeout:
            self.current_packet[0] = -1
            self.current_packet[1] = "\nTimeout"
            queue.put(self.current_packet)
            MESSAGE[1] = 129 # send message number and rx id 129 to detach
            MESSAGE[0] = self.current_packet[8]
            if self.running != 0:
                sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
            return
        except Exception as e:
            print e
            self.current_packet[0] = -2
            self.current_packet[1] = "\nConnection Error"
            queue.put(self.current_packet)
            return
    
    def handle_message(self, bdata):
        id = bdata[1]
        num = bdata[0]
        
        if self.current_packet[7] != num:  #if the received value is not expected, increment error, then set the expected value to the one received
            self.current_packet[4] += 1
            self.current_packet[7] = num 
        if self.current_packet[7] == 255: #if the value is at 255, wrap it around to 0
            self.current_packet[7] = 0
        if id < 124 and self.var_config[id].get(): 
            self.functions[id](bdata)
            
    def rec0(self, bdata):
        pass
    def rec1(self, bdata):
        pass
    def rec2(self, bdata):
        pass
    def rec3(self, bdata):
        pass
    def rec4(self, bdata):
        pass
    def rec5(self, bdata):
        pass
    def rec6(self, bdata):
        pass
    def rec7(self, bdata):
        pass
    def rec8(self, bdata):
        pass
    def rec9(self, bdata):
        pass
    def rec10(self, bdata):
        pass
    def rec11(self, bdata):
        pass
    def rec12(self, bdata):
        pass
    def rec13(self, bdata):
        pass
    def rec14(self, bdata):
        pass
    def rec15(self, bdata):
        pass
    def rec16(self, bdata):
        pass
    def rec17(self, bdata):
        pass
    def rec18(self, bdata):
        pass
    def rec19(self, bdata):
        pass
    def rec20(self, bdata):
        pass
    def rec21(self, bdata):
        pass
    def rec22(self, bdata):
        pass
    def rec23(self, bdata):
        pass
    def rec24(self, bdata):
        pass
    def rec25(self, bdata):
        pass
    def rec26(self, bdata):
        pass
    def rec27(self, bdata):
        pass
    def rec28(self, bdata):
        pass
    def rec29(self, bdata):
        pass
    def rec30(self, bdata):
        pass
    def rec31(self, bdata):
        pass
    def rec32(self, bdata):
        pass
    def rec33(self, bdata):
        pass
    def rec34(self, bdata):
        pass
    def rec35(self, bdata):
        pass
    def rec36(self, bdata):
        pass
    def rec37(self, bdata):
        pass
    def rec38(self, bdata):
        pass
    def rec39(self, bdata):
        pass
    def rec40(self, bdata):
        pass
    def rec41(self, bdata):
        pass
    def rec42(self, bdata):
        pass
    def rec43(self, bdata):
        pass
    def rec44(self, bdata):
        pass
    def rec45(self, bdata):
        pass
    def rec46(self, bdata):
        pass
    def rec47(self, bdata):
        pass
    def rec48(self, bdata):
        pass
    def rec49(self, bdata):
        pass
    def rec50(self, bdata):
        pass
    def rec51(self, bdata):
        pass
    def rec52(self, bdata):
        pass
    def rec53(self, bdata):
        pass
    def rec54(self, bdata):
        pass
    def rec55(self, bdata):
        pass
    def rec56(self, bdata):
        pass
    def rec57(self, bdata):
        pass
    def rec58(self, bdata):
        pass
    def rec59(self, bdata):
        pass
    def rec60(self, bdata):
        pass
    def rec61(self, bdata):
        pass
    def rec62(self, bdata):
        pass
    def rec63(self, bdata):
        pass
    def rec64(self, bdata):
        string = ""
        string += self.fix_num(bdata[len(bdata)-1])
        string += self.fix_num(bdata[len(bdata)-2]) 
        string += self.fix_num(bdata[len(bdata)-3])   
        string += "_"
        string += self.fix_num(bdata[len(bdata)-4])
        string += self.fix_num(bdata[len(bdata)-5]) 
        string += self.fix_num(bdata[len(bdata)-6])   
        self.current_packet[1] =  "Target : "+ string
        self.current_packet[0] = 2
        self.queue.put(copy.copy(self.current_packet))
    def rec65(self, bdata):
        pass
    def rec66(self, bdata):
        pass
    def rec67(self, bdata):
        pass
    def rec68(self, bdata):
        pass
    def rec69(self, bdata):
        pass
    def rec70(self, bdata):
        tstamp = ""
        string = ""
        for b in bdata:
            string += str(b)
        string += "\n"
        self.current_packet[1] = string
        self.current_packet[0] = 1
        print string
        self.queue.put(copy.copy(self.current_packet))
    def rec71(self, bdata):
        pass
    def rec72(self, bdata):
        pass
    def rec73(self, bdata):
        pass
    def rec74(self, bdata):
        pass
    def rec75(self, bdata):
        pass
    def rec76(self, bdata):
        pass
    def rec77(self, bdata):
        pass
    def rec78(self, bdata):
        pass
    def rec79(self, bdata):
        pass
    def rec80(self, bdata):
        pass
    def rec81(self, bdata):
        pass
    def rec82(self, bdata):
        pass
    def rec83(self, bdata):
        pass
    def rec84(self, bdata):
        pass
    def rec85(self, bdata):
        pass
    def rec86(self, bdata):
        pass
    def rec87(self, bdata):
        pass
    def rec88(self, bdata):
        pass
    def rec89(self, bdata):
        pass
    def rec80(self, bdata):
        pass
    def rec81(self, bdata):
        pass
    def rec82(self, bdata):
        pass
    def rec83(self, bdata):
        pass
    def rec84(self, bdata):
        pass
    def rec85(self, bdata):
        pass
    def rec86(self, bdata):
        pass
    def rec87(self, bdata):
        pass
    def rec88(self, bdata):
        pass
    def rec89(self, bdata):
        pass
    def rec90(self, bdata):
        pass
    def rec91(self, bdata):
        pass
    def rec92(self, bdata):
        pass
    def rec93(self, bdata):
        pass
    def rec94(self, bdata):
        pass
    def rec95(self, bdata):
        pass
    def rec96(self, bdata):
        pass
    def rec97(self, bdata):
        pass
    def rec98(self, bdata):
        pass
    def rec99(self, bdata):
        pass
    def rec100(self, bdata):
        pass
    def rec101(self, bdata):
        pass
    def rec102(self, bdata):
        pass
    def rec103(self, bdata):
        pass
    def rec104(self, bdata):
        pass
    def rec105(self, bdata):
        pass
    def rec106(self, bdata):
        pass
    def rec107(self, bdata):
        pass
    def rec108(self, bdata):
        pass
    def rec109(self, bdata):
        pass
    def rec110(self, bdata):
        pass
    def rec111(self, bdata):
        pass
    def rec112(self, bdata):
        pass
    def rec113(self, bdata):
        pass
    def rec114(self, bdata):
        pass
    def rec115(self, bdata):
        pass
    def rec116(self, bdata):
        pass
    def rec117(self, bdata):
        pass
    def rec118(self, bdata):
        pass
    def rec119(self, bdata):
        pass
    def rec120(self, bdata):
        pass
    def rec121(self, bdata):
        pass
    def rec122(self, bdata):
        pass
    def rec123(self, bdata):
        pass
    def rec124(self, bdata):
        pass
    
    def fix_num(self, num):
        if num < 10:
            if num == 0:
                return '00'
            elif num == 1:
                return '01'
            elif num == 2:
                return '02'
            elif num == 3:
                return '03'
            elif num == 4:
                return '04'
            elif num == 5:
                return '05'
            elif num == 6:
                return '06'
            elif num == 7:
                return '07'
            elif num == 8:
                return '08'
            elif num == 9:
                return '09'
        else:
            return str(num)
        
        
    def endApplication(self):
        self.running = 0
        



if __name__=="__main__":
    UDP_IP = "127.0.0.1"
    UDP_PORT = 7701
    sock = socket.socket(socket.AF_INET, # Internet
                         socket.SOCK_DGRAM) # UDP
    
    sock.settimeout(10)
    rand = random.Random()
    root = Tkinter.Tk()
    var_config = []
    for i in range(0, 124):
        var_config.append(Tkinter.IntVar())
        if i >= 70:
            var_config[i].set(True)
        else:
            var_config[i].set(False)
            
    var_config[64].set(True)

    current_packet = [0, "None", 0, 0, 0, 0, 0, 1, 1] # command num, printstr, tx, rx_from_qspy, err_from_qspy, rx_from_qp, err_from_qp, rx_check_num, tx_check_num
    client = ThreadedClient(root, sock, current_packet, var_config)
    root.mainloop()
    
    