import canvas_experiment as c
import Tkinter
import time
import threading
import random
import Queue
import socket
import sys
import binascii
import tkMessageBox
import copy

'''
This template consists of a working GUI with a thread that connects to QSpy
Currently the application automatically attempts to connect to QSpy, then waits for a client to attach
It will timeout after 10 seconds of inactivity
If QSpy is not running, it will prompt the user with a dialogue box

Comments explain how to continue to develop this file into a specialized GUI to display data for a specific QP program

'''


'''
Use this class to reference drawn objects on the canvas (lines indicating connections, shapes indicating active objects, etc)
The canvas object stores a sequential list of objects drawn on it, referenced by integers
By keeping track of the order the objects are added, and creating a variable here to reference them, the drawn objects can be
recalled using methods such as this from inside of the update() or processInformation() functions ofthe my_gui_part class
EX:               here is the gui object
self.canvas.config(self.gui.pc_oval, text="An Event Happenned")

It is important to know that the order items are drawn on the canvas in my_gui_part.initialize() must match with the value assignment in this class
The my_gui_part class comes with a GuiCodes object alread instantiated

'''
class GuiCodes:
    def __init__(self):
        #The first 28 objects are indexes in the canvas Tkinter object
        #by passing the different indexes properties of the different compononents can be changed
        #for example: self.canvas.itemconfig(self.gui.n1_disp_text, text = "Hello") grabs the Node 1 display label and changes it's text to "Hello"
        self.pc_oval = 1
        self.pc_disp_label = 2
'''
my_threaded_client is the thread that remains connected to QSpy while the main part of the program handles a Tkinter GUI (my_gui_part)
The self.initialize call sets up class variables
The self.gui = my_gui_part.... overrides the previous class GUI
the four remaining lines set the thread to start
'''
class my_threaded_client(c.ThreadedClient):
    def __init__(self, master, sock, current_packet):
        
        #has to be the first call, in extensions of the class too!
        self.initialize(master, sock, current_packet)
        # Set up the GUI part
        self.gui = my_gui_part(master, self.queue, self.endApplication, sock, self)
        #when overriding the gui with your own class, be sure to add the lines beneath here!
        # Set up the thread to do asynchronous I/O
        self.running = 1
        self.thread1 = threading.Thread(target=self.connectionThread,args=(self.sock, self.queue,))
        self.thread1.start()
        # Start the periodic call in the GUI to check the queue
        self.periodicCall(  )
    
    def handle_message(self, bdata):
        #bdata[0] = message #
        #bdata[1] = message ID
        #the rest depends on that type of message it is. Handle it here, add relevant information to self.queue, then handle in processIncoming
        id = bdata[1]
        num = bdata[0]
        #checks that numbering is correct, then increments the count and wraps if necessary
        if self.current_packet[7] != num:  #if the received value is not expected, increment error, then set the expected value to the one received
            self.current_packet[4] += 1
            self.current_packet[7] = num 
        if self.current_packet[7] == 255: #if the value is at 255, wrap it around to 0
            self.current_packet[7] = 0
            
        #handle the client info id
        if id == 64:
            self.handle_info(bdata)
    
    def handle_info(self, ascii):
        string = ""
        string += self.fix_num(ascii[len(ascii)-1])
        string += self.fix_num(ascii[len(ascii)-2]) 
        string += self.fix_num(ascii[len(ascii)-3])   
        string += "_"
        string += self.fix_num(ascii[len(ascii)-4])
        string += self.fix_num(ascii[len(ascii)-5]) 
        string += self.fix_num(ascii[len(ascii)-6])   
        self.current_packet[1] =  "Target : "+ string
        self.current_packet[0] = 2
        self.queue.put(copy.copy(self.current_packet))
'''
my_gui_part is the GUI that takes up the main thread of this program and is provided with QSpy data from the queue populated by my_threaded_client
The GUI can be defined in the initialize function
The queue is processed in the processIncoming function, which is called periodically by my_threaded_client
'''
class my_gui_part(c.GuiPart):
    #draw the GUI
    def initialize(self):
        self.gui = GuiCodes()
        #draw the GUI here
        self.canvas = Tkinter.Canvas(self.master, width = 200, height = 200)
        self.canvas.pack()
        self.master.title("Extension of QSpy Viewer")
        
        #draw the PC oval
        pc = self.canvas.create_oval(10, 50, 190, 150, fill="blue")                    # item 1
        pc_disp_text = self.canvas.create_text(100, 80, anchor="n")                     # item 2
        self.canvas.itemconfig(pc_disp_text, text="TEMPLATE", fill="white")
    '''
    processIncoming - handle data from QSpy placed in the queue by the threaded client
    each queue entry is a "packet" list formed like this
       int         str     int    int          int            int        int           int           int
    command num, datastr, tx, rx_from_qspy, err_from_qspy, rx_from_qp, err_from_qp, rx_check_num, tx_check_num
    to process more data, add to the printstr in a function like handle_data(), then process the addition in processIncoming data
    '''
    def processIncoming(self):
        while self.queue.qsize(  ):
            try:
                msg = self.queue.get(0)
                print "QSpy Data To be Processed"
                if msg[0] == -2: #if the incoming command number is -2 QSpy isn't running
                    if self.check_retry():
                        self.client.start_connection(self.sock, self.queue) #prompt users to either try to connect again or exit
                elif msg[0] == -1: #if the incoming command number is -1, display the timeout condition
                    self.canvas.itemconfig(self.gui.pc_disp_label, text="Timeout")
                    self.canvas.itemconfig(self.gui.pc_oval, fill="red")
                elif msg[0] == 2: #if the incoming command number is two, update the gui to display connection details
                    self.canvas.itemconfig(self.gui.pc_disp_label, text="Connected\n"+msg[1])
                    self.canvas.itemconfig(self.gui.pc_oval, fill="black")
                
            except Queue.Empty:
                #empty queue
                pass
        
        
if __name__=="__main__":
    #Set up the connection information
    UDP_IP = "127.0.0.1"
    UDP_PORT = 7701
    #Set up the socket
    sock = socket.socket(socket.AF_INET, # Internet
                         socket.SOCK_DGRAM) # UDP
    sock.settimeout(10)
    #instantiate different python classes
    rand = random.Random()
    root = Tkinter.Tk()
    #command num, datastr, tx, rx_from_qspy, err_from_qspy, rx_from_qp, err_from_qp, rx_check_num, tx_check_num
    current_packet = [0, "None", 0, 0, 0, 0, 0, 1, 1] 
    #initialize the threaded client
    client = my_threaded_client(root, sock, current_packet)
    #start the gui
    root.mainloop()