import Tkinter
import time
import threading
import random
import Queue
import socket
import sys
import binascii
import tkMessageBox
import copy

def fix_num(num):
    if num < 10:
        if num == 0:
            return '00'
        elif num == 1:
            return '01'
        elif num == 2:
            return '02'
        elif num == 3:
            return '03'
        elif num == 4:
            return '04'
        elif num == 5:
            return '05'
        elif num == 6:
            return '06'
        elif num == 7:
            return '07'
        elif num == 8:
            return '08'
        elif num == 9:
            return '09'
    else:
        return str(num)
        
def save_screen(sock):
    global current_packet
    values = []
    values.append(current_packet[8])
    values.append(131)
    MESSAGE = bytearray(values)
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
    #print "\nScreen Saved"
    current_packet[8] += 1
    
def save_matlab(sock):
    global current_packet
    values = []
    values.append(current_packet[8])
    values.append(133)
    MESSAGE = bytearray(values)
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
    #print "\nMatlab Saved"
    current_packet[8] += 1
    
    
def save_mscgen(sock):
    global current_packet
    values = []
    values.append(current_packet[8])
    values.append(134)
    MESSAGE = bytearray(values)
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
    #print "\nMSCGEN Saved"
    current_packet[8] += 1
    
def save_bin(sock):
    global current_packet
    values = []
    values.append(current_packet[8])
    values.append(132)
    MESSAGE = bytearray(values)
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
    #print "\nBinary Saved"
    current_packet[8] += 1
    
    
def save_dict(sock):
    global current_packet
    values = []
    values.append(current_packet[8])
    values.append(130)
    MESSAGE = bytearray(values)
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
    #print "\nDict Saved"
    current_packet[8] += 1

def handle_info(queue, ascii):
    global current_packet
    target_num = ''
    target_num += fix_num(int(ascii[34:36], 16))
    target_num += fix_num(int(ascii[32:34], 16))
    target_num += fix_num(int(ascii[30:32], 16))
    target_num += "_"
    target_num += fix_num(int(ascii[28:30], 16))
    target_num += fix_num(int(ascii[26:28], 16))
    target_num += fix_num(int(ascii[24:26], 16))
    current_packet[1] =  "Target : "+ target_num
    current_packet[0] = 2
    queue.put(copy.copy(current_packet))
    
def handle_data(queue, ascii):
    global current_packet
    status = ""
    status += chr(int(ascii[18:20], 16))
    status += chr(int(ascii[20:22],16))
    status += chr(int(ascii[22:24],16))
    status += chr(int(ascii[24:26], 16))
    status += chr(int(ascii[26:28], 16))
    status += chr(int(ascii[28:30], 16))
    status += chr(int(ascii[30:32], 16))
    status += chr(int(ascii[32:34], 16))
    status += chr(int(ascii[34:36], 16))
    tstamp = ""
    tstamp += ascii[12:10]
    tstamp += ascii[8:10]
    tstamp += ascii[6:8]
    tstamp += ascii[4:6]
    tstamp = str(int(tstamp, 16))
    if len(tstamp) < 10:
        tstamp = "0"*(10-len(tstamp)) + tstamp
    current_packet[1] = "\n"+ tstamp+" Philosopher " + str(int(ascii[14:16], 16)) + " is " + status
    current_packet[0] = 1
    queue.put(copy.copy(current_packet))
    
def send_data_on_click(sock, cmd, queue):
    global current_packet
    current_packet[0] = 1
    printstr = ""
    if cmd == 0:
        save_dict(sock)
        printstr = "Dict Saved"
    elif cmd == 1:
        save_screen(sock)
        printstr = "Text Saved"
    elif cmd == 2:
        save_bin(sock)
        printstr = "Binary Saved"
    elif cmd == 3:
        save_matlab(sock)
        printstr = "Matlab Saved"
    elif cmd == 4:
        save_mscgen(sock)
        printstr = "MSCGEN Saved"
    else:
        printstr = "Nothing Done"
    queue.put(copy.copy(current_packet))
    
def check_retry():
    return tkMessageBox.askretrycancel("QSpy Viewer", "QSpy Connection Failed")
    
def donothing():
    tkMessageBox.showinfo("a box", "Hello!")
    
class GuiPart:
    def __init__(self, master, queue, endCommand, sock, client):
        self.queue = queue
        self.master = master
        self.sock = sock
        self.end = endCommand
        self.client = client
        # Set up the GUI
        master.title("QSpy Viewer")
        menubar = Tkinter.Menu(master)
        master.config(menu=menubar)
        filemenu = Tkinter.Menu(menubar, tearoff=0)
        filemenu.add_command(label="Store Dictionaries", command=lambda:send_data_on_click(self.sock, 0, self.queue))
        filemenu.add_command(label="Screen Output", command=lambda:send_data_on_click(self.sock, 1, self.queue))
        filemenu.add_command(label="Save QS Binary", command=lambda:send_data_on_click(self.sock, 2, self.queue))
        filemenu.add_command(label="Matlab Output", command=lambda:send_data_on_click(self.sock, 3, self.queue))
        filemenu.add_command(label="MscGen Output", command=lambda:send_data_on_click(self.sock, 4, self.queue))
        filemenu.add_separator()
        filemenu.add_command(label="Exit", command=endCommand)
        menubar.add_cascade(label="File", menu=filemenu)

        viewmenu = Tkinter.Menu(menubar, tearoff=0)
        viewmenu.add_command(label="Text", command=donothing)
        viewmenu.add_command(label="Canvas", command=donothing)
        menubar.add_cascade(label="View", menu=viewmenu)

        filtermenu = Tkinter.Menu(menubar, tearoff=0)
        filtermenu.add_command(label="Global Filters...", command=donothing)
        filtermenu.add_command(label="Local Filters...", command=donothing)
        filtermenu.add_command(label="AO Filter...", command=donothing)
        menubar.add_cascade(label="Filters", menu=filtermenu)

        cmdmenu = Tkinter.Menu(menubar, tearoff=0)
        cmdmenu.add_command(label="Reset Target", command=donothing)
        cmdmenu.add_command(label="Query Target Info", command=donothing)
        cmdmenu.add_command(label="Tick[0]", command=donothing)
        cmdmenu.add_command(label="Tick[1]", command=donothing)
        cmdmenu.add_command(label="User Command...", command=donothing)
        cmdmenu.add_command(label="Peek Address...", command=donothing)
        cmdmenu.add_command(label="Poke Address...", command=donothing)
        cmdmenu.add_separator()
        menubar.add_cascade(label="Commands", menu=cmdmenu)

        eventmenu = Tkinter.Menu(menubar, tearoff=0)
        eventmenu.add_command(label="Generate Event...", command=donothing)
        menubar.add_cascade(label="Events", menu=eventmenu)

        custommenu = Tkinter.Menu(menubar, tearoff=0)
        custommenu.add_command(label="MyCommand", command=donothing)
        menubar.add_cascade(label="Custom", menu=custommenu)

        helpmenu = Tkinter.Menu(menubar, tearoff=0)
        helpmenu.add_command(label="Online Help", command=donothing)
        helpmenu.add_separator()
        helpmenu.add_command(label="About...", command=donothing)
        menubar.add_cascade(label="Help", menu=helpmenu)
        
        
        master.display_frame = Tkinter.Frame(master, width =640, height = 270 )
        master.display_frame.pack(fill = "both", expand = True)
        master.display_frame.grid_propagate(False)
        master.display_frame.grid_rowconfigure(0, weight = 1)
        master.display_frame.grid_columnconfigure(0, weight = 1)
        
        
        master.scrollbary = Tkinter.Scrollbar(master.display_frame)
        master.scrollbary.grid(row=0, column=1, sticky="nsew")

        master.scrollbarx = Tkinter.Scrollbar(master.display_frame,orient=Tkinter.HORIZONTAL)
        master.scrollbarx.grid(row=1, column=0, sticky="nsew")
        
        master.text = Tkinter.Text(master.display_frame, width=65, height=12, relief="sunken", wrap=Tkinter.NONE)
        master.text.config(state=Tkinter.NORMAL, yscrollcommand = master.scrollbary.set, xscrollcommand = master.scrollbarx.set)
        master.text.grid(row=0, column=0, sticky='nsew')
        master.scrollbary.config(command = master.text.yview)
        master.scrollbarx.config(command = master.text.xview)
        
        master.target_label = Tkinter.Label(master, text="Target : UNKNOWN")
        master.target_label.pack(side=Tkinter.LEFT)
        master.tx_label = Tkinter.Label(master, text = "   Viewer: TX")
        master.tx_label.pack(side=Tkinter.LEFT)
        master.tx_display = Tkinter.Label(master, text="0", relief="sunken", width = 4, anchor=Tkinter.W)
        master.tx_display.pack(side=Tkinter.LEFT)
        master.rx1_label = Tkinter.Label(master, text = "RX")
        master.rx1_label.pack(side=Tkinter.LEFT)
        master.rx1_display = Tkinter.Label(master, text="0", relief="sunken", width = 4, anchor=Tkinter.W)
        master.rx1_display.pack(side=Tkinter.LEFT)
        master.err1_label = Tkinter.Label(master, text = "Err")
        master.err1_label.pack(side=Tkinter.LEFT)
        master.err1_display = Tkinter.Label(master, text="0", relief="sunken", width = 4, anchor=Tkinter.W)
        master.err1_display.pack(side=Tkinter.LEFT)
        master.rx2_label = Tkinter.Label(master, text = "   Backend: RX")
        master.rx2_label.pack(side=Tkinter.LEFT)
        master.rx2_display = Tkinter.Label(master, text="0", relief="sunken", width = 4, anchor=Tkinter.W)
        master.rx2_display.pack(side=Tkinter.LEFT)
        master.err2_label = Tkinter.Label(master, text = "Err")
        master.err2_label.pack(side=Tkinter.LEFT)
        master.err2_display = Tkinter.Label(master, text="0", relief="sunken", width = 4, anchor=Tkinter.W)
        master.err2_display.pack(side=Tkinter.LEFT)
        
        # Add more GUI stuff here depending on your specific needs
        
    def processIncoming(self):
        """Handle all messages currently in the queue, if any."""
        #if self.queue.qsize():
           # print "Unloading Queue"
        while self.queue.qsize(  ):
            try:
                msg = self.queue.get(0)
                #print msg
                # Check contents of message and do whatever is needed. As a
                # simple test, print it (in real life, you would
                # suitably update the GUI's display in a richer fashion).
                if msg[0] == 1:
                    self.master.text.config(state=Tkinter.NORMAL)
                    self.master.text.insert(Tkinter.END, str(msg[1]))
                    self.master.text.config(state=Tkinter.DISABLED)
                    self.master.text.see(Tkinter.END)
                elif msg[0] == 2:
                    self.master.text.config(state=Tkinter.NORMAL)
                    self.master.text.insert(Tkinter.END, "\nTarget Connected")
                    self.master.text.config(state=Tkinter.DISABLED)
                    self.master.text.see(Tkinter.END)
                    self.master.target_label.config(text=str(msg[1]))
                elif msg[0] == -1:
                    self.master.text.config(state=Tkinter.NORMAL)
                    self.master.text.insert(Tkinter.END, str(msg[1]))
                    self.master.text.config(state=Tkinter.DISABLED)
                    self.master.text.see(Tkinter.END)
                elif msg[0] == -2:
                    self.master.text.config(state=Tkinter.NORMAL)
                    self.master.text.insert(Tkinter.END, str(msg[1]))
                    self.master.text.config(state=Tkinter.DISABLED)
                    self.master.text.see(Tkinter.END)
                    if check_retry():
                        self.client.start_connection(self.sock, self.queue)
                    else:
                        sys.exit(1)
                    
                    
                self.master.tx_display.config(text=(str(msg[2])))
                self.master.rx1_display.config(text=(str(msg[3])))
                self.master.err1_display.config(text=(str(msg[4])))
                self.master.rx2_display.config(text=(str(msg[5])))
                self.master.err2_display.config(text=(str(msg[6])))
            except Queue.Empty:
                # just on general principles, although we don't
                # expect this branch to be taken in this case
                pass
        

def connect_to_qspy(sock, queue):
    MSG = []
    data = 0
    values = [1, 128]
    MESSAGE = bytearray(values) # send message number one, rx id 128 to attach to qspy
    t = buffer(MESSAGE)
            
    printstr = "\nAttached to QSpy, waiting for Target"
    current_packet[0] = 1
    current_packet[1] = printstr
            
    try: 
        sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        current_packet[8] += 1 #increment expected tx
        current_packet[2] += 1 #increment tx counter
        data, addr = sock.recvfrom(4096) # buffer size is 4096 bytes
        current_packet[3] += 1 #increment rx counter
        current_packet[7] += 1 #increment expected rx
        bdata = bytearray(data)
        t = buffer(bdata)
        queue.put(current_packet)
        MESSAGE[1] = 0
        MESSAGE[0] = current_packet[7] # send message number two, rx id 0 to get the target ID
        sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        current_packet[8] += 1 #increment expected tx
        current_packet[2] += 1 #increment tx counter
        
        current_packet[7] -= 1
        while 1:
            data, addr = sock.recvfrom(4096) # buffer size is 4096 bytes
            current_packet[3] += 1 #increment rx counter
            current_packet[7] += 1 #increment expected rx
            bdata = bytearray(data)
            t = buffer(bdata)
            ascii = binascii.hexlify(t)
            id = int(ascii[2:4], 16)
            num = int(ascii[0:2], 16)
            if current_packet[7] != num:  #if the received value is not expected, increment error, then set the expected value to the one received
                current_packet[4] += 1
                current_packet[7] = num 
            if current_packet[7] == 255: #if the value is at 255, wrap it around to 0
                current_packet[7] = 0
            if id == 64:
                handle_info(queue, ascii)
            elif id == 70:
                handle_data(queue, ascii)
                        
    except socket.timeout:
        current_packet[0] = -1
        current_packet[1] = "\nTimeout"
        queue.put(current_packet)
        MESSAGE[1] = 129 # send message number and rx id 129 to detach
        MESSAGE[0] = current_packet[8]
        sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        return
    except Exception as e:
        print e
        current_packet[0] = -2
        current_packet[1] = "\nConnection Error"
        queue.put(current_packet)
        return
        
class ThreadedClient:
    """
    Launch the main part of the GUI and the worker thread. periodicCall and
    endApplication could reside in the GUI part, but putting them here
    means that you have all the thread controls in a single place.
    """
    def __init__(self, master, sock):
        """
        Start the GUI and the asynchronous threads. We are in the main
        (original) thread of the application, which will later be used by
        the GUI as well. We spawn a new thread for the worker (I/O).
        """
        self.master = master
        self.sock = sock
        # Create the queue
        self.queue = Queue.Queue(  )
        # Set up the GUI part
        self.gui = GuiPart(master, self.queue, self.endApplication, sock, self)

        # Set up the thread to do asynchronous I/O
        # More threads can also be created and used, if necessary
        self.running = 1
        self.thread1 = threading.Thread(target=self.workerThread1,args=(self.sock, self.queue,))
        self.thread1.start()

        # Start the periodic call in the GUI to check if the queue contains
        # anything
        self.periodicCall(  )

    def periodicCall(self):
        """
        Check every 200 ms if there is something new in the queue.
        """
        self.gui.processIncoming(  )
        if not self.running:
            # This is the brutal stop of the system. You may want to do
            # some cleanup before actually shutting it down.
            import sys
            sys.exit(1)
        self.master.after(10, self.periodicCall)
        
    def start_connection(self, sock, queue):
        self.thread1 = threading.Thread(target=self.workerThread1, args=(sock, queue,))
        self.thread1.start()

    def workerThread1(self, sock, queue):
        """
        This is where we handle the asynchronous I/O. For example, it may be
        a 'select(  )'. One important thing to remember is that the thread has
        to yield control pretty regularly, by select or otherwise.
        """
        
        connect_to_qspy(sock, queue)
        
        # To simulate asynchronous I/O, we create a random number at
        # random intervals. Replace the following two lines with the real
        # thing.  TEMPLATE
        #time.sleep(rand.random(  ) * 1.5)
        #msg = rand.random(  )
        #self.queue.put(msg)
        
                

    def endApplication(self):
        self.running = 0

        
if __name__=="__main__":
    UDP_IP = "127.0.0.1"
    UDP_PORT = 7701
    sock = socket.socket(socket.AF_INET, # Internet
                         socket.SOCK_DGRAM) # UDP
    sock.settimeout(10)
    rand = random.Random()
    root = Tkinter.Tk()
    current_packet = [0, "None", 0, 0, 0, 0, 0, 1, 1] # command num, printstr, tx, rx_from_qspy, err_from_qspy, rx_from_qp, err_from_qp, rx_check_num, tx_check_num
    client = ThreadedClient(root, sock)
    root.mainloop()
    
    