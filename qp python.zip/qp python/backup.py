import Tkinter
import time
import threading
import random
import Queue
import socket
import sys
import binascii
import tkMessageBox
import copy

def fix_num(num):
    if num < 10:
        if num == 0:
            return '00'
        elif num == 1:
            return '01'
        elif num == 2:
            return '02'
        elif num == 3:
            return '03'
        elif num == 4:
            return '04'
        elif num == 5:
            return '05'
        elif num == 6:
            return '06'
        elif num == 7:
            return '07'
        elif num == 8:
            return '08'
        elif num == 9:
            return '09'
    else:
        return str(num)
        
def save_screen(sock):
    global current_packet
    values = []
    values.append(current_packet[8])
    values.append(131) # send a packet with the rec id 131 to tell QSpy to save the output to the screen as a text file
    MESSAGE = bytearray(values)
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
    #print "\nScreen Saved"
    current_packet[8] += 1
    
def save_matlab(sock):
    global current_packet
    values = []
    values.append(current_packet[8])
    values.append(133) # send a packet with the rec id 133 to tell QSpy to save the output to the screen as a matlab file
    MESSAGE = bytearray(values)
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
    #print "\nMatlab Saved"
    current_packet[8] += 1
    
    
def save_mscgen(sock):
    global current_packet
    values = []
    values.append(current_packet[8])
    values.append(134) # send a packet with the rec id 134 to tell QSpy to save the output to the screen as a mscgen file
    MESSAGE = bytearray(values)
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
    #print "\nMSCGEN Saved"
    current_packet[8] += 1
    
def save_bin(sock):
    global current_packet
    values = []
    values.append(current_packet[8])
    values.append(132) # send a packet with the rec id 132 to tell QSpy to save the output to the screen as a binary file
    MESSAGE = bytearray(values)
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
    #print "\nBinary Saved"
    current_packet[8] += 1
    
    
def save_dict(sock):
    global current_packet
    values = []
    values.append(current_packet[8])
    values.append(130)# send a packet with the rec id 130 to tell QSpy to save the output to the screen as a dictionary file
    MESSAGE = bytearray(values)
    sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
    #print "\nDict Saved"
    current_packet[8] += 1

def handle_info(queue, ascii):
    global current_packet
    target_num = ''
    target_num += fix_num(int(ascii[34:36], 16)) #handle one number at a time, converting the hex to decimal
    target_num += fix_num(int(ascii[32:34], 16))
    target_num += fix_num(int(ascii[30:32], 16))
    target_num += "_"
    target_num += fix_num(int(ascii[28:30], 16))
    target_num += fix_num(int(ascii[26:28], 16))
    target_num += fix_num(int(ascii[24:26], 16))
    current_packet[1] =  "Target : "+ target_num
    current_packet[0] = 2
    queue.put(copy.copy(current_packet))
    
def handle_data(queue, ascii):
    global current_packet
    
    status = ""
    status += str(int(ascii[18:20], 16))
    status += " "
    status += str(int(ascii[22:24],16))
    status += " "
    status += str(int(ascii[26:28], 16))
    status += " "
    status += str(int(ascii[30:32], 16))
    status += " "
    status += str(int(ascii[34:36], 16))
    status += " "
    status += str(int(ascii[38:40], 16))
    status += " "
    status += str(int(ascii[42:44], 16))
    status += " "
    status += str(int(ascii[46:48], 16))
    status += " "
    status += str(int(ascii[50:52], 16))
    status += " "
    #status += str(int(ascii[54:56], 16))
    tstamp = ""
    tstamp += ascii[12:10]
    tstamp += ascii[8:10]
    tstamp += ascii[6:8]
    tstamp += ascii[4:6]
    tstamp = str(int(tstamp, 16))
    
    if len(tstamp) < 10:
        tstamp = "0"*(10-len(tstamp)) + tstamp
    current_packet[1] = "\n"+ tstamp+" Node " + str(int(ascii[14:16], 16)) + " is " + status
    current_packet[0] = 1
    queue.put(copy.copy(current_packet))
    
def send_data_on_click(sock, cmd, queue):
    global current_packet
    current_packet[0] = 1
    printstr = ""
    if cmd == 0:
        save_dict(sock)
        printstr = "Dict Saved"
    elif cmd == 1:
        save_screen(sock)
        printstr = "Text Saved"
    elif cmd == 2:
        save_bin(sock)
        printstr = "Binary Saved"
    elif cmd == 3:
        save_matlab(sock)
        printstr = "Matlab Saved"
    elif cmd == 4:
        save_mscgen(sock)
        printstr = "MSCGEN Saved"
    else:
        printstr = "Nothing Done"
    queue.put(copy.copy(current_packet))
    
def check_retry():
    return tkMessageBox.askretrycancel("QSpy Viewer", "QSpy Connection Failed")
    
def donothing():
    tkMessageBox.showinfo("a box", "Hello!")

    
class GuiCodes:
    def __init__(self):
        self.pc_oval = 1
        self.pc_disp_text = 2
        self.pc_disp_label = 3
        self.n1_rect = 4
        self.n1_disp_text = 5
        self.n1_disp_label = 6
        self.n2_rect = 7
        self.n2_disp_text = 8
        self.n2_disp_label = 9
        self.n3_rect = 10
        self.n3_disp_text = 11
        self.n3_disp_label = 12
        self.n4_rect = 13
        self.n4_disp_text = 14
        self.n4_disp_label = 15
class GuiPart:
    def __init__(self, master, queue, endCommand, sock, client):
        self.queue = queue
        self.master = master
        self.sock = sock
        self.end = endCommand
        self.client = client
        self.gui = GuiCodes()
        
        # Set up the GUI
       
        master.title("QSpy Viewer")
        self.canvas = Tkinter.Canvas(master, width = 600, height = 800)
        self.canvas.pack()
        
        
        pc = self.canvas.create_oval(250, 25, 350, 125, fill="blue")                    # item 1
        pc_disp_text = self.canvas.create_text(300, 37, anchor="n")                     # item 2
        self.canvas.itemconfig(pc_disp_text, text="PC", fill="white")
        pc_disp_label = self.canvas.create_text(300, 60, anchor="n")                    # item 3
        self.canvas.itemconfig(pc_disp_label, text="Disconnected", fill="white")
        
        N1 = self.canvas.create_rectangle(50, 200, 250, 400, fill="grey")               # item 4
        N1_disp_text = self.canvas.create_text(150, 210, anchor="n")                    # item 5
        self.canvas.itemconfig(N1_disp_text, text="Node 1", fill="white")
        N1_disp_label = self.canvas.create_text(150, 225, anchor="n")                   # item 6
        self.canvas.itemconfig(N1_disp_label, text="Disconnected", fill="white")
        
        N2 = self.canvas.create_rectangle(350, 200, 550, 400, fill="grey")              # item 7
        N2_disp_text = self.canvas.create_text(450, 210, anchor="n")                    # item 8
        self.canvas.itemconfig(N2_disp_text, text="Node 2", fill="white")
        N2_disp_label = self.canvas.create_text(450, 225, anchor="n")
        self.canvas.itemconfig(N2_disp_label, text="Disconnected", fill="white")        # item 9
        
        N3 = self.canvas.create_rectangle(350, 500, 550, 700, fill="grey")              # item 10
        N3_disp_text = self.canvas.create_text(450, 510, anchor="n")                    # item 11
        self.canvas.itemconfig(N3_disp_text, text="Node 3", fill="white")
        N3_disp_label = self.canvas.create_text(450, 525, anchor="n")                   # item 12
        self.canvas.itemconfig(N3_disp_label, text="Disconnected", fill="white")
        
        N4 = self.canvas.create_rectangle(50, 500, 250, 700, fill="grey")               # item 13
        N4_disp_text = self.canvas.create_text(150, 510, anchor="n")                    # item 14
        self.canvas.itemconfig(N4_disp_text, text="Node 4", fill="white")
        N4_disp_label = self.canvas.create_text(150, 525, anchor="n")                   # item 15
        self.canvas.itemconfig(N4_disp_label, text="Disconnected", fill="white")
        
        master.button = Tkinter.Button(master, text="Pause", command=lambda:self.pause())
        master.button.pack()
        # Add more GUI stuff here depending on your specific needs
        
    def pause(self):
        self.canvas.itemconfig(self.gui.pc_disp_label, text="Connected")
    def processIncoming(self):
        """Handle all messages currently in the queue, if any."""
        #if self.queue.qsize():
           # print "Unloading Queue"
        while self.queue.qsize(  ):
            try:
                msg = self.queue.get(0)
                #print msg
                # Check contents of message and do whatever is needed. As a
                # simple test, print it (in real life, you would
                # suitably update the GUI's display in a richer fashion).
                if msg[0] == 1:
                    
                elif msg[0] == 2:
                    self.canvas.itemconfig(self.gui.pc_disp_label, text="Connected")
              
                elif msg[0] == -1:
                    pass
                elif msg[0] == -2:
                   pass
                   '''
                    if check_retry():
                        self.client.start_connection(self.sock, self.queue)
                    else:
                        sys.exit(1)
                    '''
                '''    
                self.master.tx_display.config(text=(str(msg[2])))
                self.master.rx1_display.config(text=(str(msg[3])))
                self.master.err1_display.config(text=(str(msg[4])))
                self.master.rx2_display.config(text=(str(msg[5])))
                self.master.err2_display.config(text=(str(msg[6])))
                '''
            except Queue.Empty:
                # just on general principles, although we don't
                # expect this branch to be taken in this case
                pass
            

def connect_to_qspy(sock, queue):
    MSG = []
    data = 0
    values = [1, 128]
    MESSAGE = bytearray(values) # send message number one, rx id 128 to attach to qspy
    t = buffer(MESSAGE)
            
    printstr = "\nAttached to QSpy, waiting for Target"
    current_packet[0] = 1
    current_packet[1] = printstr
    print "Ug"
    try: 
        sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        current_packet[8] += 1 #increment expected tx
        current_packet[2] += 1 #increment tx counter
        data, addr = sock.recvfrom(4096) # buffer size is 4096 bytes
        current_packet[3] += 1 #increment rx counter
        current_packet[7] += 1 #increment expected rx
        bdata = bytearray(data)
        t = buffer(bdata)
        queue.put(current_packet)
        MESSAGE[1] = 0
        MESSAGE[0] = current_packet[7] # send message number two, rx id 0 to get the target ID
        sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        current_packet[8] += 1 #increment expected tx
        current_packet[2] += 1 #increment tx counter
        
        current_packet[7] -= 1
        while 1:
            data, addr = sock.recvfrom(4096) # buffer size is 4096 bytes
            current_packet[3] += 1 #increment rx counter
            current_packet[7] += 1 #increment expected rx
            bdata = bytearray(data)
            t = buffer(bdata)
            ascii = binascii.hexlify(t)
            id = int(ascii[2:4], 16)
            num = int(ascii[0:2], 16)
            if current_packet[7] != num:  #if the received value is not expected, increment error, then set the expected value to the one received
                current_packet[4] += 1
                current_packet[7] = num 
            if current_packet[7] == 255: #if the value is at 255, wrap it around to 0
                current_packet[7] = 0
            if id == 64:
                handle_info(queue, ascii)
            elif id == 70:
                handle_data(queue, ascii)
                        
    except socket.timeout:
        current_packet[0] = -1
        current_packet[1] = "\nTimeout"
        queue.put(current_packet)
        MESSAGE[1] = 129 # send message number and rx id 129 to detach
        MESSAGE[0] = current_packet[8]
        sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
        return
    except Exception as e:
        print e
        current_packet[0] = -2
        current_packet[1] = "\nConnection Error"
        queue.put(current_packet)
        return
        
class ThreadedClient:
    """
    Launch the main part of the GUI and the worker thread. periodicCall and
    endApplication could reside in the GUI part, but putting them here
    means that you have all the thread controls in a single place.
    """
    def __init__(self, master, sock):
        """
        Start the GUI and the asynchronous threads. We are in the main
        (original) thread of the application, which will later be used by
        the GUI as well. We spawn a new thread for the worker (I/O).
        """
        self.master = master
        self.sock = sock
        # Create the queue
        self.queue = Queue.Queue(  )
        # Set up the GUI part
        self.gui = GuiPart(master, self.queue, self.endApplication, sock, self)

        # Set up the thread to do asynchronous I/O
        # More threads can also be created and used, if necessary
        self.running = 1
        self.thread1 = threading.Thread(target=self.workerThread1,args=(self.sock, self.queue,))
        self.thread1.start()

        # Start the periodic call in the GUI to check if the queue contains
        # anything
        self.periodicCall(  )

    def periodicCall(self):
        """
        Check every 200 ms if there is something new in the queue.
        """
        self.gui.processIncoming(  )
        if not self.running:
            # This is the brutal stop of the system. You may want to do
            # some cleanup before actually shutting it down.
            import sys
            sys.exit(1)
        self.master.after(10, self.periodicCall)
        
    def start_connection(self, sock, queue):
        self.thread1 = threading.Thread(target=self.workerThread1, args=(sock, queue,))
        self.thread1.start()

    def workerThread1(self, sock, queue):
        """
        This is where we handle the asynchronous I/O. For example, it may be
        a 'select(  )'. One important thing to remember is that the thread has
        to yield control pretty regularly, by select or otherwise.
        """
        print "Here"
        #connect_to_qspy(sock, queue)
        
        # To simulate asynchronous I/O, we create a random number at
        # random intervals. Replace the following two lines with the real
        # thing.  TEMPLATE
        #time.sleep(rand.random(  ) * 1.5)
        #msg = rand.random(  )
        #self.queue.put(msg)
        
                

    def endApplication(self):
        self.running = 0

        
if __name__=="__main__":
    UDP_IP = "127.0.0.1"
    UDP_PORT = 7701
    sock = socket.socket(socket.AF_INET, # Internet
                         socket.SOCK_DGRAM) # UDP
    sock.settimeout(10)
    rand = random.Random()
    root = Tkinter.Tk()
    current_packet = [0, "None", 0, 0, 0, 0, 0, 1, 1] # command num, printstr, tx, rx_from_qspy, err_from_qspy, rx_from_qp, err_from_qp, rx_check_num, tx_check_num
    client = ThreadedClient(root, sock)
    root.mainloop()
    
    