import Tkinter
import time
import threading
import random
import Queue
import socket
import sys
import binascii
import tkMessageBox
import copy
import qspy_gui
   

    

    

    
'''
def pause(sock):
    print "Here"
    value = []
    value.append(1)
    value.append(16)
    value.append(6)
    value.append(6)
    value.append(1)
    #value.append(0)
    MESSAGE = bytearray(value)
    MESSAGE.append(0)
    print MESSAGE
    print sock.sendto(MESSAGE, (UDP_IP, UDP_PORT))
    #pause sent
    current_packet[8] += 1
'''    
class GuiCodes:
    def __init__(self):
        #The first 28 objects are indexes in the canvas Tkinter object
        #by passing the different indexes properties of the different compononents can be changed
        #for example: self.canvas.itemconfig(self.gui.n1_disp_text, text = "Hello") grabs the Node 1 display label and changes it's text to "Hello"
        self.pc_oval = 1
        self.pc_disp_text = 2
        self.pc_disp_label = 3
        self.n1_oval = 4
        self.n1_disp_text = 5
        self.n1_disp_label = 6
        self.n2_oval = 7
        self.n2_disp_text = 8
        self.n2_disp_label = 9
        self.n3_oval = 10
        self.n3_disp_text = 11
        self.n3_disp_label = 12
        self.n4_oval = 13
        self.n4_disp_text = 14
        self.n4_disp_label = 15
        self.fourone = 16
        self.onefour = 17
        self.twothree = 19
        self.threetwo = 18
        self.onetwo = 20
        self.twoone = 21
        self.fourthree = 22
        self.threefour = 23
        self.onethree = 24
        self.threeone = 25
        self.fourtwo = 26
        self.twofour = 27
        self.window = 28
        #array of colors referenced by the check_value() function
        self.color = ["green","yellow", "red", "grey"]
        #global max, min, and timeout time values, updated fromt textboxes in update()
        self.max = 3
        self.min = 2
        self.timeout_time = float(6.0)
        #time since active values
        self.n1_time = time.clock()
        self.n2_time = time.clock()
        self.n3_time = time.clock()
        self.n4_time = time.clock()
        #timeout flags
        self.timeout_one = False
        self.timeout_two = False
        self.timeout_three = False
        self.timeout_four = False
        #3D array model object
        #gui.data[(node number -1)][connection to node][RSSI (0) or SNR (1)]
        #connection to node for 1: 0 = 2, 1 = 3, 2 = 4; for 2: 0 = 1, 1 = 3, 2 = 4; for 3: 0 = 1, 1 = 2, 2 = 4; for 4: 0 = 1, 1 = 2, 2 = 3;
        self.data = [[[0,0],[0,0],[0,0]],[[0,0],[0,0],[0,0]],[[0,0],[0,0],[0,0]],[[0,0],[0,0],[0,0]]]
        
class MyGuiPart(qspy_gui.GuiPart):
    def __init__(self, master, queue, sock):
        self.gui = GuiCodes()
        super(MyGuiPart, self).__init__(master, queue, sock)
        


    #override this function to set up own gui
    def initialize(self):
        # Set up the GUI
        self.gui = GuiCodes()
        # Set up title, size
        self.canvas = Tkinter.Canvas(self.master, width = 800, height = 600)
        self.canvas.pack()
        self.master.title("QSpy Viewer")
        self.add_menu()
        #draw the PC oval
        pc = self.canvas.create_oval(150, 50, 350, 150, fill="grey")                    # item 1
        pc_disp_text = self.canvas.create_text(250, 75, anchor="n")                     # item 2
        self.canvas.itemconfig(pc_disp_text, text="PC", fill="white")
        pc_disp_label = self.canvas.create_text(250, 90, anchor="n")                    # item 3
        self.canvas.itemconfig(pc_disp_label, text="Disconnected", fill="white")
        #draw the Node 1 oval
        N1 = self.canvas.create_oval(50, 200, 150, 300, fill="grey")                    # item 4
        N1_disp_text = self.canvas.create_text(100, 220, anchor="n")                    # item 5
        self.canvas.itemconfig(N1_disp_text, text="Node 1", fill="white")
        N1_disp_label = self.canvas.create_text(100, 235, anchor="n")                   # item 6
        self.canvas.itemconfig(N1_disp_label, text="Inactive", fill="white")
        #draw the Node 2 oval
        N2 = self.canvas.create_oval(350, 200, 450, 300, fill="grey")                   # item 7
        N2_disp_text = self.canvas.create_text(400, 220, anchor="n")                    # item 8
        self.canvas.itemconfig(N2_disp_text, text="Node 2", fill="white")
        N2_disp_label = self.canvas.create_text(400, 235, anchor="n")
        self.canvas.itemconfig(N2_disp_label, text="Inactive", fill="white")            # item 9
        #draw the Node 3 oval
        N3 = self.canvas.create_oval(350, 500, 450, 600, fill="grey")                   # item 10
        N3_disp_text = self.canvas.create_text(400, 520, anchor="n")                    # item 11
        self.canvas.itemconfig(N3_disp_text, text="Node 3", fill="white")
        N3_disp_label = self.canvas.create_text(400, 535, anchor="n")                   # item 12
        self.canvas.itemconfig(N3_disp_label, text="Inactive", fill="white")
        #draw the Node 4 oval
        N4 = self.canvas.create_oval(50, 500, 150, 600, fill="grey")                    # item 13
        N4_disp_text = self.canvas.create_text(100, 520, anchor="n")                    # item 14
        self.canvas.itemconfig(N4_disp_text, text="Node 4", fill="white")
        N4_disp_label = self.canvas.create_text(100, 535, anchor="n")                   # item 15
        self.canvas.itemconfig(N4_disp_label, text="Inactive", fill="white")
        
        #draw the text indicators
        self.canvas.create_text(70, 400, text="0/0", anchor="n")                        # item 16
        self.canvas.create_text(127, 400, text="0/0", anchor="n")                       # item 17
        self.canvas.create_text(370, 400, text = "0/0", anchor="n")                     # item 18
        self.canvas.create_text(427, 400, text = "0/0", anchor="n")                     # item 19
        self.canvas.create_text(250, 220, text = "0/0", anchor="n")                     # item 20
        self.canvas.create_text(250, 260, text = "0/0", anchor="n")                     # item 21
        self.canvas.create_text(250, 520, text = "0/0", anchor="n")                     # item 22
        self.canvas.create_text(250, 560, text = "0/0", anchor="n")                     # item 23
        self.canvas.create_text(205, 305, text = "0/0", anchor="n")                     # item 24
        self.canvas.create_text(170, 340, text = "0/0", anchor="n")                     # item 25
        self.canvas.create_text(300, 305, text = "0/0", anchor="n")                     # item 26
        self.canvas.create_text(327, 340, text = "0/0", anchor="n")                     # item 27
        
        #create a frame to place widgets on the canvas into
        self.display_frame = Tkinter.Frame(self.master, width =280, height = 350 )
        self.display_frame.pack(fill = "none", expand = False)
        self.display_frame.grid_propagate(False)
        
        #create the "Range" section
        range_label = Tkinter.Label(self.display_frame, text="Range")
        range_label.grid(row=0, column = 2, sticky = "nsew")
        
        red_label = Tkinter.Label(self.display_frame, text="Red >", width=5)
        red_label.grid(row=1, column = 0, sticky = "nsew")
        self.high = Tkinter.Text(self.display_frame, width=2, height=1, relief="sunken") #textbox for "high" range value
        self.high.insert(Tkinter.END, "3")
        self.high.grid(row=1, column=1, sticky="nsew")
        yellow_label = Tkinter.Label(self.display_frame, text="> Yellow", width = 8)
        yellow_label.grid(row=1, column = 2, sticky = "nsew")
        self.low = Tkinter.Text(self.display_frame, width=2, height=1, relief="sunken") #textbox for "low" range value
        self.low.grid(row=1, column=3, sticky="nsew")
        self.low.insert(Tkinter.END, "2")
        green_label = Tkinter.Label(self.display_frame, text="> Green", width=7)
        green_label.grid(row=1, column = 4, sticky = "nsew")
        
        #create the "Timeout" section
        timeout_label = Tkinter.Label(self.display_frame, text = "Timeout")
        timeout_label.grid(row=2, column = 2, sticky = "nsew")
        
        after_label = Tkinter.Label(self.display_frame, text="After ")
        after_label.grid(row=3, column=2)
        self.timeout = Tkinter.Text(self.display_frame, width=2, height=1, relief="sunken") #textbox to input timeout seconds
        self.timeout.grid(row=3, column=3, sticky="nsew")
        self.timeout.insert(Tkinter.END, "9.0")
        seconds_label = Tkinter.Label(self.display_frame, text="seconds")
        seconds_label.grid(row=3, column=4)
        
        #labels to display time since active
        label_one = Tkinter.Label(self.display_frame, text = "Node 1: ")
        label_one.grid(row=4, column=2)
        self.time_one_display = Tkinter.Label(self.display_frame, text = "00.00")
        self.time_one_display.grid(row=4, column=3)
        self.one_timeout = Tkinter.Label(self.display_frame, text = "seconds")
        self.one_timeout.grid(row=4, column=4)
        label_two = Tkinter.Label(self.display_frame, text = "Node 2: ")
        label_two.grid(row=5, column=2)
        self.time_two_display = Tkinter.Label(self.display_frame, text = "00.00")
        self.time_two_display.grid(row=5, column=3)
        self.two_timeout = Tkinter.Label(self.display_frame, text = "seconds")
        self.two_timeout.grid(row=5, column=4)
        label_three = Tkinter.Label(self.display_frame, text = "Node 3: ")
        label_three.grid(row=6, column=2)
        self.time_three_display = Tkinter.Label(self.display_frame, text = "00.00")
        self.time_three_display.grid(row=6, column=3)
        self.three_timeout = Tkinter.Label(self.display_frame, text = "seconds")
        self.three_timeout.grid(row=6, column=4)
        label_four = Tkinter.Label(self.display_frame, text = "Node 4: ")
        label_four.grid(row=7, column=2)
        self.time_four_display = Tkinter.Label(self.display_frame, text = "00.00")
        self.time_four_display.grid(row=7, column=3)
        self.four_timeout = Tkinter.Label(self.display_frame, text = "seconds")
        self.four_timeout.grid(row=7, column=4)

        self.window = self.canvas.create_window(600, 50, window=self.display_frame, anchor="n", tags="window")
        
        #connecting lines
        self.canvas.create_line(152, 555, 348, 555, fill="black", width=3, tags=("four", "three", "t"))    
        self.canvas.create_line(152, 545, 348, 545, fill="black", width=3, tags=("four", "three", "f"))    
        self.canvas.create_line(152, 555, 160, 565, fill="black", width=3, tags=("four", "three", "t"))    
        self.canvas.create_line(348, 545, 340, 535, fill="black", width=3, tags=("four", "three", "f"))    
        
        self.canvas.create_line(95, 302, 95, 498, fill="black", width=3, tags=("four", "one", "f"))        
        self.canvas.create_line(105, 302, 105, 498, fill="black", width=3, tags=("four", "one", "t"))      
        self.canvas.create_line(95, 302, 85, 310, fill="black", width=3, tags=("four", "one", "f"))
        self.canvas.create_line(105, 498, 115, 490, fill="black", width=3, tags=("four", "one", "t"))
        
        self.canvas.create_line(395, 302, 395, 498, fill="black", width=3, tags=("three", "two", "t"))
        self.canvas.create_line(405, 302, 405, 498, fill="black", width=3, tags=("three", "two", "f"))
        self.canvas.create_line(395, 302, 385, 310, fill="black", width=3, tags=("three", "two", "t"))
        self.canvas.create_line(405, 498, 415, 490, fill="black", width=3, tags=("three", "two", "f"))
        
        self.canvas.create_line(152, 255, 348, 255, fill="black", width=3, tags=("one", "two", "f"))
        self.canvas.create_line(152, 245, 348, 245, fill="black", width=3, tags=("one", "two", "t"))
        self.canvas.create_line(152, 255, 160, 265, fill="black", width=3, tags=("one", "two", "f"))
        self.canvas.create_line(348, 245, 340, 235, fill="black", width=3, tags=("one", "two", "t"))
        
        self.canvas.create_line(145, 282, 362, 512, fill="black", width=3, tags=("diag1", "t"))
        self.canvas.create_line(138, 290, 355, 520, fill="black", width=3, tags=("diag1", "f"))
        self.canvas.create_line(362, 512, 362, 497, fill="black", width=3, tags=("diag1", "t"))
        self.canvas.create_line(138, 290, 138, 305, fill="black", width=3, tags=("diag1", "f"))
        
        self.canvas.create_line(138, 512, 355, 282, fill="black", width=3, tags=("diag2", "t"))
        self.canvas.create_line(145, 520, 362, 290, fill="black", width=3, tags=("diag2", "f"))
        self.canvas.create_line(355, 282, 341, 282, fill="black",  width=3, tags=("diag2", "t"))
        self.canvas.create_line(145, 520, 159, 520, fill="black", width=3, tags=("diag2", "f"))
        
        
   
    def processIncoming(self):
        #handle data added to the queue since the last call
        while self.queue.qsize(  ):
            try:
                msg = self.queue.get(0)
                #print msg
                # Check contents of message and do whatever is needed. As a
                # simple test, print it (in real life, you would
                # suitably update the GUI's display in a richer fashion).
                if msg[0] == 1:         #if the command number (msg[0]) is 1, handle incoming data
                    if self.log_setting.get():
                        self.file.write(str(msg[1]))
                    l = msg[1].split()  #self.client.current_packet[1].split() #the array of data is stored in a space seperated string at 
                    if int(l[0]) == 1:  #If the active node is one, update the 3D data array correctly
                        #NOTE data comes in in the format: active node, n1_rssi, n1_snr, n2_rssi, n2_snr, n3_rssi, n3_snr, n4_rssi, n4_snr
                        #additional data to process should be added at the end
                        self.gui.data[0][0][0] = l[3]
                        self.gui.data[0][0][1] = l[4]
                        self.gui.data[0][1][0] = l[5]
                        self.gui.data[0][1][1] = l[6]
                        self.gui.data[0][2][0] = l[7]
                        self.gui.data[0][2][1] = l[8]
                        if self.gui.timeout_one == False:   #if node one has not timed out, display the node as active
                            self.canvas.itemconfig(self.gui.n1_disp_label, text="Active")
                            self.canvas.itemconfig(self.gui.n1_oval, fill="blue")
                        #display the previous node as inactive
                        self.canvas.itemconfig(self.gui.n4_oval, fill="grey")
                        self.canvas.itemconfig(self.gui.n4_disp_label, text="Inactive")
                    #the same thing happens for two through four (consolidate)
                    elif int(l[0]) == 2:
                        self.gui.data[1][0][0] = l[1]
                        self.gui.data[1][0][1] = l[2]
                        self.gui.data[1][1][0] = l[5]
                        self.gui.data[1][1][1] = l[6]
                        self.gui.data[1][2][0] = l[7]
                        self.gui.data[1][2][1] = l[8]
                        if self.gui.timeout_two == False:
                            self.canvas.itemconfig(self.gui.n2_disp_label, text="Active")
                            self.canvas.itemconfig(self.gui.n2_oval, fill="blue")
                        self.canvas.itemconfig(self.gui.n1_oval, fill="grey")
                        self.canvas.itemconfig(self.gui.n1_disp_label, text="Inactive")
                      
                    elif int(l[0]) == 3:
                        self.gui.data[2][0][0] = l[1]
                        self.gui.data[2][0][1] = l[2]
                        self.gui.data[2][1][0] = l[3]
                        self.gui.data[2][1][1] = l[4]
                        self.gui.data[2][2][0] = l[7]
                        self.gui.data[2][2][1] = l[8]
                        if self.gui.timeout_three == False:
                            self.canvas.itemconfig(self.gui.n3_disp_label, text="Active")
                            self.canvas.itemconfig(self.gui.n3_oval, fill="blue")
                        self.canvas.itemconfig(self.gui.n2_oval, fill="grey")
                        self.canvas.itemconfig(self.gui.n2_disp_label, text="Inactive")
                        
                    elif int(l[0]) == 4:
                        self.gui.data[3][0][0] = l[1]
                        self.gui.data[3][0][1] = l[2]
                        self.gui.data[3][1][0] = l[3]
                        self.gui.data[3][1][1] = l[4]
                        self.gui.data[3][2][0] = l[5]
                        self.gui.data[3][2][1] = l[6]
                        if self.gui.timeout_four == False:
                            self.canvas.itemconfig(self.gui.n4_disp_label, text="Active")
                            self.canvas.itemconfig(self.gui.n3_disp_label, text="Inactive")
                            self.canvas.itemconfig(self.gui.n4_oval, fill="blue")
                        self.canvas.itemconfig(self.gui.n3_oval, fill="grey")
                    self.update(int(l[0])) #Then update the gui    
                elif msg[0] == 2: #if the incoming command number is two, update the gui to display connection details
                    self.canvas.itemconfig(self.gui.pc_disp_label, text="Connected\n"+msg[1])
                    self.canvas.itemconfig(self.gui.pc_oval, fill="black")
                    if self.log_setting.get():
                        self.file.write("Connected\n"+msg[1]+"\n")
                elif msg[0] == -1: #if the incoming command number is -1, display the timeout condition
                    self.canvas.itemconfig(self.gui.pc_disp_label, text="Timeout")
                    if self.log_setting.get():
                        self.file.write("Timeout\n")
                    self.canvas.itemconfig(self.gui.pc_oval, fill="red")
                elif msg[0] == -2: #if the incoming command number is -2, prompt to reconnect or quit
                    if self.check_retry():
                        self.client.start_connection(self.sock, self.queue)
                    else:
                        sys.exit(1)
                    
                
            except Queue.Empty:
                #empty queue
                pass
    
    def check_val(self, num): # compare the value in the model to the max and min boundary values, return the correct color index
        if num > self.gui.max:
            return 2
        elif num > self.gui.min:
            return 1
        else:
            return 0
            
    def update_time(self): #update the waiting time of the nodes, if a timeout has occured signal it
        #format the time string
        str_one = "%.3f" % (time.clock() - self.gui.n1_time)
        str_two = "%.3f" % (time.clock() - self.gui.n2_time)
        str_three = "%.3f" % (time.clock() - self.gui.n3_time)
        str_four = "%.3f" % (time.clock() - self.gui.n4_time)
        
        #update the active node's time labels
        if self.gui.timeout_one == False:
            self.time_one_display.config(text=str_one)
        if self.gui.timeout_two == False:
            self.time_two_display.config(text=str_two)
        if self.gui.timeout_three == False:
            self.time_three_display.config(text=str_three)
        if self.gui.timeout_four == False:
            self.time_four_display.config(text=str_four)
        #check for a timeout, if so set the flag true
        if (time.clock() - self.gui.n1_time) > self.gui.timeout_time:
            self.one_timeout.config(text="Timeout")
            self.gui.timeout_one = True
        if (time.clock() - self.gui.n2_time) > self.gui.timeout_time:
            self.two_timeout.config(text="Timeout")
            self.gui.timeout_two = True
        if (time.clock() - self.gui.n3_time) > self.gui.timeout_time:
            self.three_timeout.config(text="Timeout")
            self.gui.timeout_three = True
        if (time.clock() - self.gui.n4_time) > self.gui.timeout_time:
            self.four_timeout.config(text="Timeout")
            self.gui.timeout_four = True
            
    #override this function to update custom guis     
    def update(self, num): #update the gui with the new data
        
        #set the time of the active node to 0
        if num == 1:
            self.gui.n1_time= time.clock()
        
        if num == 2:
            self.gui.n2_time = time.clock()
        
        if num == 3:
            self.gui.n3_time = time.clock()
        
        if num == 4:
            self.gui.n4_time = time.clock()
        #update any max, min, or timeout values from the textboxes
        try:
            self.gui.max = int(self.high.get("1.0", Tkinter.END))
            self.gui.min = int(self.low.get("1.0", Tkinter.END))
            self.gui.timeout_time = float(self.timeout.get("1.0", Tkinter.END))
        except:
            print "text box exception"
            
        #update the time labels/timeout flags
        self.update_time()
        
        #update the arrow colors
        for m in self.canvas.find_withtag("three"): # grab all the objects with label "3"
            t = self.canvas.gettags(m) #use the tags within this subset to grab individual arrows and set their color based on the values in the self.gui.data model
            if t == ('three', 'two', 't'): #from 3 to 2
                if self.gui.timeout_three == False:
                    self.canvas.itemconfig(m, fill=self.gui.color[self.check_val(int(self.gui.data[2][1][0]))])
                    self.canvas.itemconfig(self.gui.threetwo, text=(str(self.gui.data[2][1][0]) + "/" + str(self.gui.data[2][1][1]))) #set the display label also
                else:
                    self.canvas.itemconfig(m, fill=self.gui.color[3])
            elif t == ('four', 'three', 't'): # from 3 to 4
                if self.gui.timeout_three == False:
                    self.canvas.itemconfig(m, fill=self.gui.color[self.check_val(int(self.gui.data[2][2][0]))])
                    self.canvas.itemconfig(self.gui.threefour, text=(str(self.gui.data[2][2][0]) + "/" + str(self.gui.data[2][2][1])))
                else:
                    self.canvas.itemconfig(m, fill=self.gui.color[3])
            elif t == ('four', 'three', 'f'): # from 4 to 3
                if self.gui.timeout_four == False:
                    self.canvas.itemconfig(m, fill=self.gui.color[self.check_val(int(self.gui.data[3][2][0]))])
                    self.canvas.itemconfig(self.gui.fourthree, text=(str(self.gui.data[3][2][0]) + "/" + str(self.gui.data[3][2][1])))
                else:
                    self.canvas.itemconfig(m, fill=self.gui.color[3])
            elif t == ('three', 'two', 'f'): # from 2 to 3
                if self.gui.timeout_two == False:
                    self.canvas.itemconfig(m, fill=self.gui.color[self.check_val(int(self.gui.data[1][1][0]))])
                    self.canvas.itemconfig(self.gui.twothree, text=(str(self.gui.data[1][1][0]) + "/" + str(self.gui.data[1][1][1])))
                else:
                    self.canvas.itemconfig(m, fill=self.gui.color[3])
        for m in self.canvas.find_withtag("one"):
            t = self.canvas.gettags(m)
            if t == ('four', 'one', 't'): #from 1 to 4
                if self.gui.timeout_one == False:
                    self.canvas.itemconfig(m, fill=self.gui.color[self.check_val(int(self.gui.data[0][2][0]))])
                    self.canvas.itemconfig(self.gui.onefour, text=(str(self.gui.data[0][2][0]) + "/" + str(self.gui.data[0][2][1])))
                else:
                    self.canvas.itemconfig(m, fill=self.gui.color[3])
            elif t == ('four', 'one', 'f'): # from 4 to 1
                if self.gui.timeout_four == False:
                    self.canvas.itemconfig(m, fill=self.gui.color[self.check_val(int(self.gui.data[3][0][0]))])
                    self.canvas.itemconfig(self.gui.fourone, text=(str(self.gui.data[3][0][0]) + "/" + str(self.gui.data[3][0][1])))
                else:
                    self.canvas.itemconfig(m, fill=self.gui.color[3])
            elif t == ('one', 'two', 't'): # from 1 to 2
                if self.gui.timeout_one == False:
                    self.canvas.itemconfig(m, fill=self.gui.color[self.check_val(int(self.gui.data[0][0][0]))])
                    self.canvas.itemconfig(self.gui.onetwo, text=(str(self.gui.data[0][0][0]) + "/" + str(self.gui.data[0][0][1])))
                else:
                    self.canvas.itemconfig(m, fill=self.gui.color[3])
            elif t == ('one', 'two', 'f'): # from 2 to 1
                if self.gui.timeout_two ==False:
                    self.canvas.itemconfig(m, fill=self.gui.color[self.check_val(int(self.gui.data[1][0][0]))])
                    self.canvas.itemconfig(self.gui.twoone, text=(str(self.gui.data[1][0][0]) + "/" + str(self.gui.data[1][0][1])))
                else:
                    self.canvas.itemconfig(m, fill=self.gui.color[3])
        for m in self.canvas.find_withtag("diag1"):
            t = self.canvas.gettags(m)
            if t == ('diag1', 'f'): # from 3 to 1
                if self.gui.timeout_three == False:
                    self.canvas.itemconfig(m, fill=self.gui.color[self.check_val(int(self.gui.data[2][0][0]))])
                    self.canvas.itemconfig(self.gui.threeone, text=(str(self.gui.data[2][0][0]) + "/" + str(self.gui.data[2][0][1])))
                else:
                    self.canvas.itemconfig(m, fill=self.gui.color[3])
            if t == ('diag1', 't'): # from 1 to 3
                if self.gui.timeout_one == False:
                    self.canvas.itemconfig(m, fill=self.gui.color[self.check_val(int(self.gui.data[0][1][0]))])
                    self.canvas.itemconfig(self.gui.onethree, text=(str(self.gui.data[0][1][0]) + "/" + str(self.gui.data[0][1][1])))
                else:
                    self.canvas.itemconfig(m, fill=self.gui.color[3])
        for m in self.canvas.find_withtag("diag2"):
            t = self.canvas.gettags(m)
            if t == ('diag2', 'f'): # from 2 to 4
                if self.gui.timeout_two == False:
                    self.canvas.itemconfig(m, fill=self.gui.color[self.check_val(int(self.gui.data[1][2][0]))])
                    self.canvas.itemconfig(self.gui.twofour, text=(str(self.gui.data[1][2][0]) + "/" + str(self.gui.data[1][2][1])))
                else:
                    self.canvas.itemconfig(m, fill=self.gui.color[3])
            if t == ('diag2', 't'): # from 4 to 2
                if self.gui.timeout_four == False:
                    self.canvas.itemconfig(m, fill=self.gui.color[self.check_val(int(self.gui.data[3][1][0]))])
                    self.canvas.itemconfig(self.gui.fourtwo, text=(str(self.gui.data[3][1][0]) + "/" + str(self.gui.data[3][1][1])))
                else:
                    self.canvas.itemconfig(m, fill=self.gui.color[3])
                    
    

if __name__=="__main__":
    args = qspy_gui.gui_args()
    gui = MyGuiPart(args[0], args[1], args[2])
   
    # command num, printstr, tx, rx_from_qspy, err_from_qspy, rx_from_qp, err_from_qp, rx_check_num, tx_check_num
    # to process more data, add to the printstr in a function like handle_data(), then process the addition in processIncoming data
    current_packet = [0, "None", 0, 0, 0, 0, 0, 1, 1] 
    client = qspy_gui.ThreadedClient(args[0], args[1], args[2], gui, current_packet)
    args[0].mainloop()
    
    